
var sql = "SELECT BIZDOMAIN,VALUE_DESC FROM RBIZDOMAIN_VALUE WHERE 1=1 AND BIZDOMAIN='ASA:OLE/*/*/Application' ";
sql+= "AND SERV_PROV_CODE = '" + aa.getServiceProviderCode() + "'";

var initialContext = aa.proxyInvoker.newInstance("javax.naming.InitialContext", null).getOutput(); var ds = initialContext.lookup("java:/AA"); var conn = ds.getConnection(); var sStmt = conn.prepareStatement(sql);
var rSet = sStmt.executeQuery();    


if (!rSet) {
	aa.print("no data");
}

while (rSet.next()) {
	
	aa.print(rSet.getString("BIZDOMAIN") + "=" + rSet.getString("VALUE_DESC"));
}
	

rSet.close();
sStmt.close();
conn.close();
