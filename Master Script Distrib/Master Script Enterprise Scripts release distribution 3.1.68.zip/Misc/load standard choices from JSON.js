x = [{
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***Application Before Update Works!!***');"
	}, {
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feesInvoicedTotal == 0  && matches(getAppSpecific('Current Plan Review #'), 0) && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('You must calculate and then pay submittal fee(s)');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ arrayFees = aa.fee.getFeeItems(capId).getOutput();"
	}, {
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [comment('There are fee(s) that have not been invoiced')];"
	}, {
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [cancel=true];"
	}, {
		"BIZDOMAIN" : "APPLICATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/13/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "balanceDue != 0  && matches(getAppSpecific('Current Plan Review #'), 0) && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Submittal fee must be paid in full');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***Application Issued Before Update Works!!***');"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'Custom Home') && !feeExists('BLDSUBRES010', 'INVOICED') ^ comment('Can not complete Application Acceptance until the Submittal fee is created,invoiced and paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'Building for Occupancy', 'Building for Completion', 'Multi Family') && !feeExists('BLDCOMSUB100', 'INVOICED') ^ comment('Can not complete Application Acceptance until the Submittal fee is created and Invoiced');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'TI for Completion', 'TI for Occupancy') && !feeExists('BLDCOMSUB110', 'INVOICED') ^ comment('Can not complete Application Acceptance until the Submittal fee is created and Invoiced');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Plan Type'), 'SFD') && !feeExists('BLDSUBSP010', 'INVOICED') ^ comment('Can not complete Application Acceptance until the Submittal fee is created, invoiced and paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') && !feeExists('FPSUB010', 'INVOICED') ^ comment('Can not complete Application Acceptance until the Submittal fee is created, invoiced and paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ arrayFees = aa.fee.getFeeItems(capId).getOutput();"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [comment('There are fee(s) that have not been invoiced')];"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [cancel=true];"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'Custom Home') && matches(getAppSpecific('Current Plan Review #'), 0) && feeExists('BLDSUBRES010', 'INVOICED') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not complete Application Acceptance until the Submittal fee is paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'Building for Occupancy', 'Building for Completion', 'Multi Family') && matches(getAppSpecific('Current Plan Review #'), 0) && feeExists('BLDCOMSUB100') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not complete Application Acceptance until the Submittal fee is paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Project Type'), 'TI for Completion', 'TI for Occupancy') && matches(getAppSpecific('Current Plan Review #'), 1) && feeExists('BLDCOMSUB110') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not complete Application Acceptance until the Submittal fee is paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && matches(getAppSpecific('Plan Type'), 'SFD') && matches(getAppSpecific('Current Plan Review #'), 0) && feeExists('BLDCOMSUB110', 'INVOICED') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not complete Application Acceptance until the Submittal fee is paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "APPLICATION_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "6/30/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && feeExists('FPSUB010', 'INVOICED') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not complete Application Acceptance until the Submittal fee is paid');cancel=true;"
	}, {
		"BIZDOMAIN" : "ApplicationSpecificInfoUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/24/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ApplicationSpecificInfoUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment(getAppSpecific('Issue Permit without full payment') );"
	}, {
		"BIZDOMAIN" : "ApplicationSpecificInfoUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "{Issue Permit without full payment} == 'Yes' && currentUserGroup != 'BLDDIR' ^ cancel = true;"
	}, {
		"BIZDOMAIN" : "ApplicationSpecificInfoUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ comment({Issue Permit without full payment});"
	}, {
		"BIZDOMAIN" : "ApplicationStatusUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;FLDarray = new Array"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ branch('ASI_TABLE_DEFAULT')"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ copyParcelGisObjects()"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "proximityToAttribute('ACCELA','floodplain','50','feet','ZONE','AE') ^ comment('This Application is within 500 feet of an AE floodplain Zone.');FLDarray = getGISBufferInfo('ACCELA','floodplain','500','ZONE', 'DESCRIPTIO'); for (x in FLDarray) comment('This Application exists within 500 feet of the following Floodplain Zones.' + FLDarray[x]['ZONE'] + ' ' + FLDarray[x]['DESCRIPTIO'])"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ editAppSpecific('Zoning', getGISInfo('ACCELA', 'Zoning', 'ZONETYPE'))"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^  editAppSpecific('Current Plan Review #', 0)"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ editAppSpecific('Issue Permit without full payment', 'No')"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('New CAP Alt ID: ' + capIDString + ' Project Name: ' + getShortNotes())"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks','The following project has entered Application Acceptance.  Please complete next Workflow Tasks.' + '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitAfter",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^  editAppSpecific('Completeness Review #', 0)"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/8/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = false;"
	}, {
		"BIZDOMAIN" : "ApplicationSubmitBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/8/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "proximity('ACCELA', 'river', 300) ^ showMessage = true; message='River within 300 feet'"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') ^ branch('BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Saftey/Pool-Spa/*') ^ branch('BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Saftey/Model Home Complex/*') ^ branch('BLDMHC_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Saftey/Standard Plan SFD Permit/*') ^ branch('BLDSFD_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Saftey/Standard Plans/*') ^ branch('BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') ^ branch('ENGUTILITY_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ branch('ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Map Revision/*') ^ branch('ENGMAPREV_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/Pre Application/*/*') ^ branch('PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') ^ branch('PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/Rezone/*/*') ^ branch('PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ branch('PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/House Plan/*/*') ^ branch('PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ branch('PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Alarm Permit/*') ^ branch('FPALARM_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Sprinkler Permit/*') ^ branch('FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') ^ branch('BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') ^ branch('BLDCODE_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Accessory Use/*') ^ branch('BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Review/*') ^ branch('BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Code Permit/*') ^ branch('FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Access/*') ^ branch('FPACCESS_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Alternative Fire Extinguishing/*') ^ branch('FPAFES_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Flammable & Combustable Liquid/*') ^ branch('FPTANK_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 26,
		"BIZDOMAIN_VALUE2" : "A26",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Hazardous Material/*') ^ branch('FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 27,
		"BIZDOMAIN_VALUE2" : "A27",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Spraying Operation/*') ^ branch('FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 28,
		"BIZDOMAIN_VALUE2" : "A28",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Technical Assistance Review/*') ^ branch('FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "ASI_TABLE_DEFAULT",
		"BIZDOMAIN_VALUE" : 29,
		"BIZDOMAIN_VALUE2" : "A29",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Temporary Use Permit/*') ^ branch('FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS');"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; varX = getValCalc();varY=getValMul();varFE='N'"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Temporary Sales Trailer') && !feeExists('BLDPERMIT050', 'NEW') && !feeExists('BLDPERMIT050', 'INVOICED') ^ addFee('BLDPERMIT050','BUILDING','FY 13-14', getAppSpecific('Temporary Sales Trailer'), 'N');varFE='Y'"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Temporary Construction Trailer') && !feeExists('BLDPERMIT060', 'NEW') && !feeExists('BLDPERMIT060', 'INVOICED') ^ addFee('BLDPERMIT060','BUILDING','FY 13-14', getAppSpecific('Temporary Construction Trailer'), 'N');varFE='Y'"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'Temporary Sales Trailer') && !matches(getAppSpecific('Project Type'), 'Temporary Construction Trailer') && !feeExists('BLDPERMIT040', 'NEW') && !feeExists('BLDPERMIT040', 'INVOICED') ^ addFee('BLDPERMIT040', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT040') && !feeExists('BLDPLNREV070', 'NEW') && !feeExists('BLDPLNREV070', 'INVOICED') ^ addFee('BLDPLNREV070', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT050') && !feeExists('BLDPLNREV080', 'NEW') && !feeExists('BLDPLNREV080', 'INVOICED') ^ addFee('BLDPLNREV080', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT060') && !feeExists('BLDPLNREV090', 'NEW') && !feeExists('BLDPLNREV090', 'INVOICED') ^ addFee('BLDPLNREV090', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Plan Review Hours') > 0 && !feeExists('BLDFREV010', 'NEW') && !feeExists('BLDFREV010', 'INVOICED') ^ addFee('BLDFREV010', 'BUILDING', '2008.Q4',getAppSpecific('Fire Plan Review Hours'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('BLDPERMIT100', 'NEW') && !feeExists('BLDPERMIT100', 'INVOICED') && varFE=='N'  ^ addFee('BLDPERMIT010', 'BUILDING', '2008.Q4', varX, 'N');varFA=feeAmount('BLDPERMIT010');addFee( 'BLDPERMIT100','BUILDING','2008.Q4',varFA*varY, 'N');removeFee('BLDPERMIT010', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_AU_ADD_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT100') && !feeExists('BLDPLNREV110') ^ addFee('BLDPLNREV110', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_ELEC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MECH_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_PLMB_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_AU_ADD_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_AU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "4/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_OCCUPANCY_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_BPK_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Business Park') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV200', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV200');addFee( 'BLDDVM010','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV200', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Business Park') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM020', 'NEW') && !feeExists('BLDDVM020', 'INVOICED') ^ addFee('BLDDEV210', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV210');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV210', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Business Park') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM030', 'NEW') && !feeExists('BLDDVM030', 'INVOICED') ^ addFee('BLDDEV220', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV220');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV220', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_BPK_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/4/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Business Park') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM040', 'NEW') && !feeExists('BLDDVM040', 'INVOICED') ^ addFee('BLDDEV230', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV230');addFee( 'BLDDVM040','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV230', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') ^ branch('BLD_COM_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') ^ branch('BLD_OFF_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Business Park') ^ branch('BLD_BPK_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Light Industrial') ^ branch('BLD_LIND_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Manufacturing') ^ branch('BLD_MAN_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Warehousing') ^ branch('BLD_WHS_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') ^ branch('BLD_HTL_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') ^ branch('BLD_MULT_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ if(matches(getAppSpecific('Dev and Impact Use'), 'Multi Family')) [branch('BLD_MTR_MULT_FEES')]; else branch('BLD_MTR_COMM_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hospital') ^ branch('BLD_HOSP_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Elementary School') || matches(getAppSpecific('Dev and Impact Use'), 'Middle School') || matches(getAppSpecific('Dev and Impact Use'), 'High School') ^ branch('BLD_SCHL_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Day Care') ^ branch('BLD_DAYC_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') ^ branch('BLD_HM_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CALC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "11/18/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Cemetery') ^ branch('BLD_CEMT_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CEMT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "2/1/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_CEMT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "2/1/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Cemetery') && getAppSpecific('# of Acres (Cemetery)') > 0 && !feeExists('BLDDEV550', 'NEW') && !feeExists('BLDDEV550', 'INVOICED') ^ addFee('BLDDEV550', 'BUILDING', '2008.Q4', getAppSpecific('# of Acres (Cemetery)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CEMT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "2/1/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Cemetery') && getAppSpecific('# of Acres (Cemetery)') > 0 && !feeExists('BLDDEV560', 'NEW') && !feeExists('BLDDEV560', 'INVOICED') ^ addFee('BLDDEV560', 'BUILDING', '2008.Q4', getAppSpecific('# of Acres (Cemetery)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CEMT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "2/1/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Cemetery') && getAppSpecific('# of Acres (Cemetery)') > 0 && !feeExists('BLDDEV570', 'NEW') && !feeExists('BLDDEV570', 'INVOICED') ^ addFee('BLDDEV570', 'BUILDING', '2008.Q4', getAppSpecific('# of Acres (Cemetery)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CEMT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "2/1/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Cemetery') && getAppSpecific('# of Acres (Cemetery)') > 0 && !feeExists('BLDDEV580', 'NEW') && !feeExists('BLDDEV580', 'INVOICED') ^ addFee('BLDDEV580', 'BUILDING', '2008.Q4', getAppSpecific('# of Acres (Cemetery)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_ELEC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MECH_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_PLMB_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Demolition') && !feeExists('BLDPERMIT020', 'NEW') && !feeExists('BLDPERMIT020', 'INVOICED') ^ addFee( 'BLDPERMIT020','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Demolition Accessory Structure') && !feeExists('BLDPERMIT030', 'NEW') && !feeExists('BLDPERMIT030', 'INVOICED') ^ addFee( 'BLDPERMIT030','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/30/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_OCCUPANCY_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_COM_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_COM_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Building for Occupancy', 'Building for Completion', 'Multi Family') && !feeExists('BLDCOMSUB100', 'NEW') && !feeExists('BLDCOMSUB100', 'INVOICED')   ^ addFee('BLDCOMSUB100', 'BUILDING', 'FY 13-14', getAppSpecific('Proposed Sq Ft'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_ADD_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'TI for Completion', 'TI for Occupancy') && !feeExists('BLDCOMSUB110', 'NEW') && !feeExists('BLDCOMSUB110', 'INVOICED')  ^ addFee('BLDCOMSUB110', 'BUILDING', 'FY 13-14', getAppSpecific('Proposed Sq Ft'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_COM_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV010', 'NEW') && !feeExists('BLDDEV010', 'INVOICED') ^ addFee('BLDDEV010', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV020', 'NEW') && !feeExists('BLDDEV020', 'INVOICED') ^ addFee('BLDDEV020', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV030', 'NEW') && !feeExists('BLDDEV030', 'INVOICED') ^ addFee('BLDDEV030', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV040', 'NEW') && !feeExists('BLDDEV040', 'INVOICED') ^ addFee('BLDDEV040', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV050', 'NEW') && !feeExists('BLDDEV050', 'INVOICED') ^ addFee('BLDDEV050', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV060', 'NEW') && !feeExists('BLDDEV060', 'INVOICED') ^ addFee('BLDDEV060', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV010') && !feeExists('BLDINFL010', 'NEW') && !feeExists('BLDINFL010', 'INVOICED') ^ addFee('BLDINFL010', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV010'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV020') && !feeExists('BLDINFL020', 'NEW') && !feeExists('BLDINFL020', 'INVOICED') ^ addFee('BLDINFL020', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV020'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV030') && !feeExists('BLDINFL030', 'NEW') && !feeExists('BLDINFL030', 'INVOICED') ^ addFee('BLDINFL030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV030'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV040') && !feeExists('BLDINFL040', 'NEW') && !feeExists('BLDINFL040', 'INVOICED') ^ addFee('BLDINFL040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV040'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV050') && !feeExists('BLDINFL050', 'NEW') && !feeExists('BLDINFL050', 'INVOICED') ^ addFee('BLDINFL050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV050'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV060') && !feeExists('BLDINFL060', 'NEW') && !feeExists('BLDINFL060', 'INVOICED') ^ addFee('BLDINFL060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV060'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;"
	}, {
		"BIZDOMAIN" : "BLD_COM_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('License Verified') != 'Yes' ^ comment('Can not Approve if License Verified is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_COM_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Verify Necessary Engineering Plans Approved') != 'Yes' ^ comment('Can not Approve if Verify Necessary Engineering Permits Issued is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_COM_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Verify Necessary Engineering Permits Issued') != 'Yes' ^ comment('Can not Approve if Verify Necessary Engineering Plans Approved is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; branch('REMVOVE_ESTIMATE_FEES'); varX = getValCalc();varY=getValMul();"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') && !feeExists('BLDPERMIT100', 'NEW') && !feeExists('BLDPERMIT100', 'INVOICED') ^ addFee('BLDPERMIT010', 'BUILDING', '2008.Q4', varX, 'N');varFA=feeAmount('BLDPERMIT010');addFee( 'BLDPERMIT100','BUILDING','2008.Q4',varFA*varY, 'N');removeFee('BLDPERMIT010', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') ^ branch('BLD_ELEC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') ^ branch('BLD_MECH_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') ^ branch('BLD_PLMB_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDCOMSUB110') && !feeExists('BLDSUBREF010') ^ addFee( 'BLDSUBREF010','BUILDING','FY 13-14', -feeAmount('BLDCOMSUB110','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDCOMSUB100') && !feeExists('BLDSUBREF010') ^ addFee( 'BLDSUBREF010','BUILDING','FY 13-14', -feeAmount('BLDCOMSUB100','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT100') && !feeExists('BLDCOMPLNREV', 'INVOICED') && !feeExists('BLDCOMPLNREV', 'NEW') ^ addFee('BLDCOMPLNREV', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') ^ branch('BLD_CALC_DEV_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!matches(getAppSpecific('Project Type'), 'No Work TI') && getAppSpecific('Fire Plan Review Hours') > 0 && !feeExists('BLDFCOM010', 'NEW') && !feeExists('BLDFCOM010', 'INVOICED') ^ addFee('BLDFCOM010', 'BUILDING', '2008.Q4',getAppSpecific('Fire Plan Review Hours'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Landscape Inspection') == 'CHECKED' && !feeExists('PLNLDS010', 'NEW') && !feeExists('PLNLDS010','INVOICED') ^ addFee('PLNLDS010', 'PLANNING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_COM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/12/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_OCCUPANCY_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_DAYC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_DAYC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Day Care') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV150', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV150');addFee( 'BLDDVM010','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV150', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_DAYC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Day Care') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM020', 'NEW') && !feeExists('BLDDVM020', 'INVOICED') ^ addFee('BLDDEV160', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV160');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV160', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_DAYC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Day Care') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM030', 'NEW') && !feeExists('BLDDVM030', 'INVOICED') ^ addFee('BLDDEV170', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV170');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV170', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_DAYC_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Day Care') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM040', 'NEW') && !feeExists('BLDDVM040', 'INVOICED') ^ addFee('BLDDEV180', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV180');addFee( 'BLDDVM040','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV180', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_DEV_FEES_COM",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/12/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_DEV_FEES_COM",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/12/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_DEV_FEES_COM branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_DEV_FEES_COM",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/12/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Proposed Sq Ft') < 25001  ^ addFee('BLDDEV010', 'BUILDING', '2008.Q4', 1, 'N'); comment('Transportation <25,000');"
	}, {
		"BIZDOMAIN" : "BLD_DEV_FEES_COM",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/12/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Proposed Sq Ft') > 25000 && getAppSpecific('Proposed Sq Ft') < 50000 ^ addFee('BLDDEV010', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug =false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_ECO_INC_FND branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV010') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV010','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV020') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV020','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV030') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV030','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV040') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV040','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV050') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV050','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Commercial') && feeExists('BLDDEV060') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV060','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV100') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV100','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV110') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV110','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV120') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV120','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV130') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV130','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV140') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV140','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && feeExists('BLDDEV150') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV150','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV300') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV300','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV310') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV310','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV320') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV320','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV330') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV330','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV340') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV340','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && feeExists('BLDDEV350') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV350','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Charge Water Development Fee') == 'Yes' && !feeExists('BLDEIF010', 'NEW') && !feeExists('BLDEIF010', 'INVOICED') ^ infillFee('BLDEIF010','BUILDING','FY 14-15','BLDWDEV010','BLDWDEV020','BLDWDEV030','BLDWDEV040','BLDWDEV050','BLDWDEV060','BLDWDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Charge Sewer Development Fee') == 'Yes' && !feeExists('BLDEIF020', 'NEW') && !feeExists('BLDEIF020', 'INVOICED') ^ infillFee('BLDEIF020','BUILDING','FY 14-15','BLDSDEV010','BLDSDEV020','BLDSDEV030','BLDSDEV040','BLDSDEV050','BLDSDEV060','BLDSDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV810') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV810','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV820') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV820','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV830') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV830','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 26,
		"BIZDOMAIN_VALUE2" : "A26",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV840') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV840','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 27,
		"BIZDOMAIN_VALUE2" : "A27",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV850') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV850','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 28,
		"BIZDOMAIN_VALUE2" : "A28",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && feeExists('BLDDEV860') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV860','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 29,
		"BIZDOMAIN_VALUE2" : "A29",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV810') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV810','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 30,
		"BIZDOMAIN_VALUE2" : "A30",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV820') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV820','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 31,
		"BIZDOMAIN_VALUE2" : "A31",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV830') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV830','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 32,
		"BIZDOMAIN_VALUE2" : "A32",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV840') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV840','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 33,
		"BIZDOMAIN_VALUE2" : "A33",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV850') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV850','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 34,
		"BIZDOMAIN_VALUE2" : "A34",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && feeExists('BLDDEV860') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV860','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 35,
		"BIZDOMAIN_VALUE2" : "A35",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV700') && !feeExists('BLDEIF030', 'NEW') && !feeExists('BLDEIF030', 'INVOICED') ^ addFee('BLDEIF030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV700','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 36,
		"BIZDOMAIN_VALUE2" : "A36",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV710') && !feeExists('BLDEIF040', 'NEW') && !feeExists('BLDEIF040', 'INVOICED') ^ addFee('BLDEIF040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV710','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 37,
		"BIZDOMAIN_VALUE2" : "A37",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV720') && !feeExists('BLDEIF080', 'NEW') && !feeExists('BLDEIF080', 'INVOICED') ^ addFee('BLDEIF080', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV720','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 38,
		"BIZDOMAIN_VALUE2" : "A38",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV730') && !feeExists('BLDEIF070', 'NEW') && !feeExists('BLDEIF070', 'INVOICED') ^ addFee('BLDEIF070', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV730','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 39,
		"BIZDOMAIN_VALUE2" : "A39",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV750') && !feeExists('BLDEIF060', 'NEW') && !feeExists('BLDEIF060', 'INVOICED') ^ addFee('BLDEIF060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV750','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ECO_INC_FND",
		"BIZDOMAIN_VALUE" : 40,
		"BIZDOMAIN_VALUE2" : "A40",
		"REC_DATE" : "9/15/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && feeExists('BLDDEV740') && !feeExists('BLDEIF050', 'NEW') && !feeExists('BLDEIF050', 'INVOICED') ^ addFee('BLDEIF050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV740','NEW'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('600 volts or less and not over 200 amperes in rating, each') > 0 && !feeExists('BLDELEC040', 'NEW') && !feeExists('BLDELEC040', 'INVOICED') ^ addFee('BLDELEC040', 'BUILDING', '2008.Q4', getAppSpecific('600 volts or less and not over 200 amperes in rating, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('600 volts or less and over 200 amperes to 1,000 amperes, each') > 0 && !feeExists('BLDELEC050', 'NEW') && !feeExists('BLDELEC050', 'INVOICED') ^ addFee('BLDELEC050', 'BUILDING', '2008.Q4', getAppSpecific('600 volts or less and over 200 amperes to 1,000 amperes, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('600 volts or over 1,000 amperes in rating, each') > 0 && !feeExists('BLDELEC060', 'NEW') && !feeExists('BLDELEC060', 'INVOICED') ^ addFee('BLDELEC060', 'BUILDING', 'FY 13-14',getAppSpecific('600 volts or over 1,000 amperes in rating, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Generator, each') > 0 && !feeExists('BLDELEC070', 'NEW') && !feeExists('BLDELEC070', 'INVOICED') ^ addFee('BLDELEC070', 'BUILDING', '2008.Q4',getAppSpecific('Generator, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_ELEC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/11/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') && getAppSpecific('Electrical Permit') > 0 && !feeExists('BLDELEC010', 'NEW') && !feeExists('BLDELEC010', 'INVOICED') ^ addFee('BLDELEC010', 'BUILDING', '2008.Q4',getAppSpecific('Electrical Permit'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***EMAIL AFTER***');"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ branch('SND_EMAIL_2')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Plan Check') && wfStatus.equals('Not Approved') ^ branch('SND_EMAIL_3')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "(wfTask.equals('Plot Plan Review') && wfStatus.equals('Not Approved')) || (wfTask.equals('Engineering Staff Review') && wfStatus.equals('Not Approved')) ^ branch('SND_EMAIL_4')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Staff Review') && wfStatus.equals('Not Approved') ^ branch('SND_EMAIL_5')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_6')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Engineering Staff Review') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_7')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Staff Review') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_8')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Docs for PC') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_9')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('PC Hearing') && wfStatus.equals('Recommend Approval') ^ branch('SND_EMAIL_10')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Docs for CC') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_11')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('CC Hearing') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_12')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Docs for PC 1') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_13')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('PC Hearing 1') && wfStatus.equals('Recommend Approval') ^ branch('SND_EMAIL_14')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Docs for PC 2') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_15')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('PC Hearing 2') && wfStatus.equals('Recommend Approval') ^ branch('SND_EMAIL_16')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('CC Hearing') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_17')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Documentation') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_18')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Mylar Sign Off') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_19')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Transmittal 2') && wfStatus.equals('Transmittal Sent') ^ branch('SND_EMAIL_20')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Mylars to Client') && wfStatus.equals('Client Picked Up Mylars') ^ branch('SND_EMAIL_21')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Mylar Distribution') && wfStatus.equals('Distribution Complete') ^ branch('SND_EMAIL_22')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ branch('SND_EMAIL_23')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Approval') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_24')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "(wfTask.equals('Inspections') || wfTask.equals('Inspection')) && wfStatus.equals('Finaled') ^ branch('SND_EMAIL_25')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 26,
		"BIZDOMAIN_VALUE2" : "A26",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Inspections') && wfStatus.equals('Complete') ^ branch('SND_EMAIL_26')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 27,
		"BIZDOMAIN_VALUE2" : "A27",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('C of O/C of C') && wfStatus.equals('Issued') ^ branch('SND_EMAIL_27')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 28,
		"BIZDOMAIN_VALUE2" : "A28",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Plan Release') && wfStatus.equals('Plan Released') ^ branch('SND_EMAIL_28')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 29,
		"BIZDOMAIN_VALUE2" : "A29",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Create Model') && wfStatus.equals('Model Created') ^ branch('SND_EMAIL_29')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 30,
		"BIZDOMAIN_VALUE2" : "A30",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Mylar Review') && wfStatus.equals('Not Approved') ^ branch('SND_EMAIL_30')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 31,
		"BIZDOMAIN_VALUE2" : "A31",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Final Inspection') && wfStatus.equals('Passed') ^ branch('SND_EMAIL_31')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 32,
		"BIZDOMAIN_VALUE2" : "A32",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Submit As-Builts') && wfStatus.equals('Submitted') ^ branch('SND_EMAIL_32')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 33,
		"BIZDOMAIN_VALUE2" : "A33",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Engineering Review As-Builts') && wfStatus.equals('Not Approved') ^ branch('SND_EMAIL_33')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 34,
		"BIZDOMAIN_VALUE2" : "A34",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Engineering Review As-Builts') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_34')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 35,
		"BIZDOMAIN_VALUE2" : "A35",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Acceptance') && wfStatus.equals('Final Acceptance') ^ branch('SND_EMAIL_35')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 36,
		"BIZDOMAIN_VALUE2" : "A36",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Warranty Inspections') && wfStatus.equals('Passed') ^ branch('SND_EMAIL_36')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 37,
		"BIZDOMAIN_VALUE2" : "A37",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Review As-Builts') && wfStatus.equals('Not Approved') ^ branch('SND_EMAIL_37')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 38,
		"BIZDOMAIN_VALUE2" : "A38",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Review As-Builts') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_38')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 39,
		"BIZDOMAIN_VALUE2" : "A39",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Hold Meeting') && wfStatus.equals('Meeting Held') ^ branch('SND_EMAIL_39')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 40,
		"BIZDOMAIN_VALUE2" : "A40",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Prepare Docs for BofA') && wfStatus.equals('Documentation Complete') ^ branch('SND_EMAIL_40')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 41,
		"BIZDOMAIN_VALUE2" : "A41",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('BofA Hearing') && wfStatus.equals('Approved') ^ branch('SND_EMAIL_41')"
	}, {
		"BIZDOMAIN" : "BLD_EMAIL_AFTER",
		"BIZDOMAIN_VALUE" : 42,
		"BIZDOMAIN_VALUE2" : "A42",
		"REC_DATE" : "1/26/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Fire Inspections') && wfStatus.equals('Finaled') ^ branch('SND_EMAIL_42')"
	}, {
		"BIZDOMAIN" : "BLD_ENG_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = true;showMessage=true;"
	}, {
		"BIZDOMAIN" : "BLD_ENG_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Verify Liability insurance on file') != 'Yes' ^ comment('Can not Approve if Verify Liability insurance on file is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_ENG_PERMIT_BEFORE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Verify contractor information') != 'Yes' ^ comment('Can not Approve if Verify contractor information is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_HM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_HM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# of Rooms (Hotel/Motel)') > 0 && !feeExists('BLDDEV450', 'NEW') && !feeExists('BLDDEV450', 'INVOICED') ^ addFee('BLDDEV450', 'BUILDING', '2008.Q4', getAppSpecific('# of Rooms (Hotel/Motel)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_HM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# of Rooms (Hotel/Motel)') > 0 && !feeExists('BLDDEV460', 'NEW') && !feeExists('BLDDEV460', 'INVOICED') ^ addFee('BLDDEV460', 'BUILDING', '2008.Q4', getAppSpecific('# of Rooms (Hotel/Motel)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_HM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# of Rooms (Hotel/Motel)') > 0 && !feeExists('BLDDEV470', 'NEW') && !feeExists('BLDDEV470', 'INVOICED') ^ addFee('BLDDEV470', 'BUILDING', '2008.Q4', getAppSpecific('# of Rooms (Hotel/Motel)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_HM_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# of Rooms (Hotel/Motel)') > 0 && !feeExists('BLDDEV480', 'NEW') && !feeExists('BLDDEV480', 'INVOICED') ^ addFee('BLDDEV480', 'BUILDING', '2008.Q4', getAppSpecific('# of Rooms (Hotel/Motel)'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_HOSP_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_HOSP_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hospital') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV900', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV900');addFee( 'BLDDVM010','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV900', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_HOSP_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hospital') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM020', 'NEW') && !feeExists('BLDDVM020', 'INVOICED') ^ addFee('BLDDEV910', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV910');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV910', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_HOSP_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hospital') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM030', 'NEW') && !feeExists('BLDDVM030', 'INVOICED') ^ addFee('BLDDEV920', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV920');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV920', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_HOSP_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hospital') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM040', 'NEW') && !feeExists('BLDDVM040', 'INVOICED') ^ addFee('BLDDEV930', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV930');addFee( 'BLDDVM040','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV930', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_BPK_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# Units/Rooms (Multi Family Only)') > 0 ^ addFee('BLDDEV600', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# Units/Rooms (Multi Family Only)') > 0 ^ addFee('BLDDEV610', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# Units/Rooms (Multi Family Only)') > 0 ^ addFee('BLDDEV620', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_HTL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Hotel/Motel') && getAppSpecific('# Units/Rooms (Multi Family Only)') > 0 ^ addFee('BLDDEV630', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_LIND_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV300', 'NEW') && !feeExists('BLDDEV300', 'INVOICED') ^ addFee('BLDDEV300', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV310', 'NEW') && !feeExists('BLDDEV310', 'INVOICED') ^ addFee('BLDDEV310', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV320', 'NEW') && !feeExists('BLDDEV320', 'INVOICED') ^ addFee('BLDDEV320', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV330', 'NEW') && !feeExists('BLDDEV330', 'INVOICED') ^ addFee('BLDDEV330', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV340', 'NEW') && !feeExists('BLDDEV340', 'INVOICED') ^ addFee('BLDDEV340', 'BLDAU', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Industrial') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV350', 'NEW') && !feeExists('BLDDEV350', 'INVOICED') ^ addFee('BLDDEV350', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV300') && !feeExists('BLDINFL010', 'NEW') && !feeExists('BLDINF010', 'INVOICED') ^ addFee('BLDINFL010', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV300'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV310') && !feeExists('BLDINFL020', 'NEW') && !feeExists('BLDINFL020', 'INVOICED') ^ addFee('BLDINFL020', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV310'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV320') && !feeExists('BLDINFL030', 'NEW') && !feeExists('BLDINFL030', 'INVOICED') ^ addFee('BLDINFL030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV320'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV330') && !feeExists('BLDINFL040', 'NEW') && !feeExists('BLDINFL040', 'INVOICED') ^ addFee('BLDINFL040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV330'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV340') && !feeExists('BLDINFL050', 'NEW') && !feeExists('BLDINFL050', 'INVOICED') ^ addFee('BLDINFL050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV340'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_LIND_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "6/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV350') && !feeExists('BLDINFL060', 'NEW') && !feeExists('BLDINFL060', 'INVOICED') ^ addFee('BLDINFL060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV350'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_MAN_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Manufacturing') && getAppSpecific('Proposed Sq Ft') > 0 ^ addFee('BLDDEV400', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Manufacturing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM020', 'NEW') && !feeExists('BLDDVM020', 'INVOICED') ^ addFee('BLDDEV410', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV410');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV410', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Manufacturing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM030', 'NEW') && !feeExists('BLDDVM030', 'INVOICED') ^ addFee('BLDDEV420', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV420');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV420', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_MAN_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/3/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Manufacturing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM040', 'NEW') && !feeExists('BLDDVM040', 'INVOICED') ^ addFee('BLDDEV430', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV430');addFee( 'BLDDVM040','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV430', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_MECH_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/5/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MECH_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/5/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Residential single-family, each') > 0 && !feeExists('BLDMECH030', 'NEW') && !feeExists('BLDMECH030', 'INVOICED') ^ addFee('BLDMECH030', 'BUILDING', '2008.Q4',getAppSpecific('Residential single-family, each') , 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MECH_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "4/5/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other than residential single-family (per unit without duct work)') > 0 && !feeExists('BLDMECH040', 'NEW') && !feeExists('BLDMECH040', 'INVOICED') ^ addFee('BLDMECH040', 'BUILDING', '2008.Q4',getAppSpecific('Other than residential single-family (per unit without duct work)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MECH_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "4/5/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other than residential single-family (per unit with duct work)') > 0 && !feeExists('BLDMECH050', 'NEW') && !feeExists('BLDMECH050', 'INVOICED') ^ addFee('BLDMECH050', 'BUILDING', '2008.Q4',getAppSpecific('Other than residential single-family (per unit with duct work)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MECH_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "4/5/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') && getAppSpecific('Mechanical Permit') > 0 && !feeExists('BLDMECH010', 'NEW') && !feeExists('BLDMECH010', 'INVOICED') ^ addFee('BLDMECH010', 'BUILDING', '2008.Q4',getAppSpecific('Mechanical Permit'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MHC_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MHC_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Building for Occupancy', 'Building for Completion', 'Multi Family') && !feeExists('BLDCOMSUB100', 'NEW') && !feeExists('BLDCOMSUB100', 'INVOICED')   ^ addFee('BLDCOMSUB100', 'BUILDING', '2008.Q4', getAppSpecific('Proposed Sq Ft'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MHC_ADD_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'TI for Completion', 'TI for Occupancy') && !feeExists('BLDCOMSUB110', 'NEW') && !feeExists('BLDCOMSUB110', 'INVOICED')  ^ addFee('BLDCOMSUB110', 'BUILDING', '2008.Q4', getAppSpecific('Proposed Sq Ft'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MHC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MHC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Plan Review Hours') > 0 && !feeExists('BLDFMHC010', 'NEW') && !feeExists('BLDFMHC010', 'INVOICED') ^ addFee('BLDFMHC010', 'BUILDING', '2008.Q4',getAppSpecific('Fire Plan Review Hours'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('COMWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Landscape') > 0 ^ addFee('COMWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('COMWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Landscape') > 0 ^ addFee('COMWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('COMWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Landscape') > 0 ^ addFee('COMWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('COMWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Landscape') > 0 ^ addFee('COMWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Domestic') > 0 ^ addFee('COMWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Landscape') > 0 ^ addFee('COMWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Domestic') > 0 ^ addFee('COMWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Landscape') > 0 ^ addFee('COMWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Domestic') > 0 ^ addFee('COMWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Landscape') > 0 ^ addFee('COMWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of Sewer Taps') > 0 ^ addFee('COMSHKP010','BUILDING','2008.Q4', getAppSpecific('Number of Sewer Taps'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Water Development Fee') == 'Yes' ^ infillFee('BLDINF010','BUILDING','FY 14-15','BLDWDEV010','BLDWDEV020','BLDWDEV030','BLDWDEV040','BLDWDEV050','BLDWDEV060','BLDWDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_COMM_FEES",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Sewer Development Fee') == 'Yes' ^ infillFee('BLDINF020','BUILDING','FY 14-15','BLDSDEV010','BLDSDEV020','BLDSDEV030','BLDSDEV040','BLDSDEV050','BLDSDEV060','BLDSDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = true; showMessage = true;comment('****BLD_MTR_MULT_FEES WORKS!!')"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('MLTWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Landscape') > 0 ^ addFee('MLTWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('MLTWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Landscape') > 0 ^ addFee('MLTWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('MLTWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Landscape') > 0 ^ addFee('MLTWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('MLTWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Landscape') > 0 ^ addFee('MLTWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Domestic') > 0 ^ addFee('MLTWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Landscape') > 0 ^ addFee('MLTWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Domestic') > 0 ^ addFee('MLTWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Landscape') > 0 ^ addFee('MLTWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Domestic') > 0 ^ addFee('MLTWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Landscape') > 0 ^ addFee('MLTWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of Sewer Taps') > 0 ^ addFee('MLTSHKP010','BUILDING','2008.Q4', getAppSpecific('Number of Sewer Taps'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Water Development Fee') == 'Yes' ^ infillFee('BLDINF010','BUILDING','FY 14-15','BLDWDEV010','BLDWDEV020','BLDWDEV030','BLDWDEV040','BLDWDEV050','BLDWDEV060','BLDWDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_MULT_FEES",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Sewer Development Fee') == 'Yes' ^ infillFee('BLDINF020','BUILDING','FY 14-15','BLDSDEV010','BLDSDEV020','BLDSDEV030','BLDSDEV040','BLDSDEV050','BLDSDEV060','BLDSDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('BLD_MTR_RES_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('RESWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('RESWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('RESWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('RESWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of Sewer Taps') > 0 ^ addFee('RESSHKP010','BUILDING','2008.Q4', getAppSpecific('Number of Sewer Taps'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Water Development Fee') == 'Yes' ^ infillFee('BLDINF010','BUILDING','FY 14-15','BLDWDEV010','BLDWDEV020','BLDWDEV030','BLDWDEV040','BLDWDEV050','BLDWDEV060','BLDWDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_RES_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Sewer Development Fee') == 'Yes' ^ infillFee('BLDINF020','BUILDING','FY 14-15','BLDSDEV010','BLDSDEV020','BLDSDEV030','BLDSDEV040','BLDSDEV050','BLDSDEV060','BLDSDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('REVCWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Landscape') > 0 ^ addFee('REVCWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('REVCWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Landscape') > 0 ^ addFee('REVCWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('REVCWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Landscape') > 0 ^ addFee('REVCWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('REVCWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Landscape') > 0 ^ addFee('REVCWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Domestic') > 0 ^ addFee('REVCWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Landscape') > 0 ^ addFee('REVCWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Domestic') > 0 ^ addFee('REVCWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Landscape') > 0 ^ addFee('REVCWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Domestic') > 0 ^ addFee('REVCWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVC_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Landscape') > 0 ^ addFee('REVCWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('REVRWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Landscape') > 0 ^ addFee('REVRWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('REVRWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Landscape') > 0 ^ addFee('REVRWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('REVRWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Landscape') > 0 ^ addFee('REVRWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('REVRWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Landscape') > 0 ^ addFee('REVRWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Domestic') > 0 ^ addFee('REVRWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Landscape') > 0 ^ addFee('REVRWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Domestic') > 0 ^ addFee('REVRWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Landscape') > 0 ^ addFee('REVRWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Domestic') > 0 ^ addFee('REVRWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_REVR_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "5/4/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 6 in Landscape') > 0 ^ addFee('REVRWMTR070','BUILDING','2008.Q4', getAppSpecific('Number of 6 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV070','BUILDING','FY 14-15', getAppSpecific('Number of 6 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_MTR_SFD_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Domestic') > 0 ^ addFee('SFDWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3/4 in Landscape') > 0 ^ addFee('SFDWMTR010','BUILDING','2008.Q4', getAppSpecific('Number of 3/4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV010','BUILDING','FY 14-15', getAppSpecific('Number of 3/4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Domestic') > 0 ^ addFee('SFDWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 in Landscape') > 0 ^ addFee('SFDWMTR020','BUILDING','2008.Q4', getAppSpecific('Number of 1 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV020','BUILDING','FY 14-15', getAppSpecific('Number of 1 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Domestic') > 0 ^ addFee('SFDWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 1 1/2 in Landscape') > 0 ^ addFee('SFDWMTR030','BUILDING','2008.Q4', getAppSpecific('Number of 1 1/2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV030','BUILDING','FY 14-15', getAppSpecific('Number of 1 1/2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Domestic') > 0 ^ addFee('SFDWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 2 in Landscape') > 0 ^ addFee('SFDWMTR040','BUILDING','2008.Q4', getAppSpecific('Number of 2 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV040','BUILDING','FY 14-15', getAppSpecific('Number of 2 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Domestic') > 0 ^ addFee('SFDWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 3 in Landscape') > 0 ^ addFee('SFDWMTR050','BUILDING','2008.Q4', getAppSpecific('Number of 3 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV050','BUILDING','FY 14-15', getAppSpecific('Number of 3 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Domestic') > 0 ^ addFee('SFDWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Domestic'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];if(getAppSpecific('Charge Sewer Development Fee') == 'Yes') [addFee('BLDSDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Domestic'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of 4 in Landscape') > 0 ^ addFee('SFDWMTR060','BUILDING','2008.Q4', getAppSpecific('Number of 4 in Landscape'), 'N'); if(getAppSpecific('Charge Water Development Fee') == 'Yes') [addFee('BLDWDEV060','BUILDING','FY 14-15', getAppSpecific('Number of 4 in Landscape'), 'N')];"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Number of Sewer Taps') > 0 ^ addFee('SFDSHKP010','BUILDING','2008.Q4', getAppSpecific('Number of Sewer Taps'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Water Development Fee') == 'Yes' ^ infillFee('BLDINF010','BUILDING','FY 14-15','BLDWDEV010','BLDWDEV020','BLDWDEV030','BLDWDEV040','BLDWDEV050','BLDWDEV060','BLDWDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MTR_SFD_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && getAppSpecific('Charge Sewer Development Fee') == 'Yes' ^ infillFee('BLDINF020','BUILDING','FY 14-15','BLDSDEV010','BLDSDEV020','BLDSDEV030','BLDSDEV040','BLDSDEV050','BLDSDEV060','BLDSDEV070','N');"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug =true; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_MULT_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV700', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV710', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV720', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV730', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV740', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_MULT_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "11/19/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Multi Family') && getAppSpecific('# of Rooms/Units (Multi-Family only)') > 0 ^ addFee('BLDDEV750', 'BUILDING', 'FY 14-15', getAppSpecific('# of Rooms/Units (Multi-Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Commercial Buildings/*') && matches(getAppSpecific('Project Type'), 'Building for Occupancy') && !feeExists('BLDCOO010','NEW') && !feeExists('BLDCOO010','INVOICED') ^ addFee('BLDCOO010', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Commercial Buildings/*') && matches(getAppSpecific('Project Type'), 'Building for Completion') && !feeExists('BLDCOC010', 'NEW') && !feeExists('BLDCOC010', 'INVOICED') ^ addFee('BLDCOC010', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Commercial Buildings/*') && matches(getAppSpecific('Project Type'), 'TI for Completion') && !feeExists('BLDCOC020', 'NEW') && !feeExists('BLDCOC020', 'INVOICED') ^ addFee('BLDCOC020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Commercial Buildings/*') && matches(getAppSpecific('Project Type'), 'TI for Occupancy', 'No Work TI') && !feeExists('BLDCOO020', 'NEW') && !feeExists('BLDCOO020', 'INVOICED') ^ addFee('BLDCOO020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Commercial Buildings/*') && matches(getAppSpecific('Project Type'), 'Multi Family') && !feeExists('BLDCOO030', 'NEW') && !feeExists('BLDCOO030', 'INVOICED') ^ addFee('BLDCOO030', 'BUILDING', '2008.Q4', getAppSpecific('# Rooms/Units (Multi Family only)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && !feeExists('BLDCOO020','NEW') && !feeExists('BLDCOO020','INVOICED') ^ addFee( 'BLDCOO020','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Residential/*') && !feeExists('BLDCOO020','NEW') && !feeExists('BLDCOO020','INVOICED') ^ addFee( 'BLDCOO020','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OCCUPANCY_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/27/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Certificate Issued?') == 'Yes' && appMatch('Building/Building Safety/Accessory Use/*') && !feeExists('BLDCOO020','NEW') && !feeExists('BLDCOO020','INVOICED') ^ addFee( 'BLDCOO020','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('RAD - BLD_OFF_DEV_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV100', 'NEW') && !feeExists('BLDDEV100', 'INVOICED') ^ addFee('BLDDEV100', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV110', 'NEW') && !feeExists('BLDDEV110', 'INVOICED') ^ addFee('BLDDEV110', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV120', 'NEW') && !feeExists('BLDDEV120', 'INVOICED') ^ addFee('BLDDEV120', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV130', 'NEW') && !feeExists('BLDDEV130', 'INVOICED') ^ addFee('BLDDEV130', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV140', 'NEW') && !feeExists('BLDDEV140', 'INVOICED') ^ addFee('BLDDEV140', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Office') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDEV150', 'NEW') && !feeExists('BLDDEV150', 'INVOICED') ^ addFee('BLDDEV150', 'BUILDING', 'FY 14-15', getAppSpecific('Development Fee Sq Ft'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV100') && !feeExists('BLDINFL010', 'NEW') && !feeExists('BLDINF010', 'INVOICED') ^ addFee('BLDINFL010', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV100'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV110') && !feeExists('BLDINFL020', 'NEW') && !feeExists('BLDINF020', 'INVOICED') ^ addFee('BLDINFL020', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV110'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV120') && !feeExists('BLDINFL030', 'NEW') && !feeExists('BLDINF030', 'INVOICED') ^ addFee('BLDINFL030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV120'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV130') && !feeExists('BLDINFL040', 'NEW') && !feeExists('BLDINF040', 'INVOICED') ^ addFee('BLDINFL040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV130'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV140') && !feeExists('BLDINFL050', 'NEW') && !feeExists('BLDINF050', 'INVOICED') ^ addFee('BLDINFL050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV140'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_OFF_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "1/5/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV150') && !feeExists('BLDINFL060', 'NEW') && !feeExists('BLDINF060', 'INVOICED') ^ addFee('BLDINFL060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV150'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_ADD_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "12/23/2008",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Appliance or equipment regulated by Plumbing Code not classed in any other categories.') > 0 && !feeExists('BLDPLMB060') ^ addFee('BLDPLMB060', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Plumbing Permit') == 'Yes' && !feeExists('BLDPLMB010', 'NEW') && !feeExists('BLDPLMB010','INVOICED') ^ addFee('BLDPLMB010', 'BUILDING', '2008.Q4',1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Multi-family or hotels/motels (per unit or room)') > 0 && !feeExists('BLDPLMB020', 'NEW') && !feeExists('BLDPLMB020', 'INVOICED') ^ addFee('BLDPLMB020', 'BUILDING', '2008.Q4',getAppSpecific('Multi-family or hotels/motels (per unit or room)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Industrial Waste Pretreatment Interceptor/Trap, each') > 0 && !feeExists('BLDPLMB040', 'NEW') && !feeExists('BLDPLMB040','INVOICED') ^ addFee('BLDPLMB040', 'BUILDING', '2008.Q4',getAppSpecific('Industrial Waste Pretreatment Interceptor/Trap, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Rainwater systems, per drain (inside building)') > 0 && !feeExists('BLDPLMB050', 'NEW') && !feeExists('BLDPLMB050','INVOICED') ^ addFee('BLDPLMB050', 'BUILDING', '2008.Q4',getAppSpecific('Rainwater systems, per drain (inside building)'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Appliance/Piece of equipment, each') > 0 && !feeExists('BLDPLMB060', 'NEW') && !feeExists('BLDPLMB060','INVOICED') ^ addFee('BLDPLMB060', 'BUILDING', '2008.Q4',getAppSpecific('Appliance/Piece of equipment, each'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_PLMB_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/31/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') && getAppSpecific('Plumbing Permit') > 0 && !feeExists('BLDPLMB010', 'NEW') && !feeExists('BLDPLMB010', 'INVOICED') ^ addFee('BLDPLMB010', 'BUILDING', '2008.Q4',getAppSpecific('Plumbing Permit'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = false;"
	}, {
		"BIZDOMAIN" : "BLD_POOL_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Spa') && !feeExists('BLDPOOL010', 'NEW') && !feeExists('BLDPOOL010', 'INVOICED') ^ addFee('BLDPOOL010', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_ADD_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Pool') && !feeExists('BLDPOOL020', 'NEW') && !feeExists('BLDPOOL020', 'INVOICED')  ^ addFee('BLDPOOL020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_ADD_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matchmatches(getAppSpecific('Pool Type'), 'Pool/Spa') && !feeExists('BLDPOOL030', 'NEW') && !feeExists('BLDPOOL030', 'INVOICED') ^ addFee('BLDPOOL030', 'BUILDING', 'FY 13-14', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Spa') && !feeExists('BLDPOOL010', 'NEW') && !feeExists('BLDPOOL010', 'INVOICED') ^ addFee('BLDPOOL010', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Pool') && getAppSpecific('Above ground?') == 'Yes' && !feeExists('BLDPOOL020', 'NEW') && !feeExists('BLDPOOL020', 'INVOICED') ^ addFee('BLDPOOL020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Pool') && getAppSpecific('Above ground?') != 'Yes' && !feeExists('BLDPOOL025', 'NEW') && !feeExists('BLDPOOL025', 'INVOICED') ^ addFee('BLDPOOL025', 'BUILDING', 'FY 13-14', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Pool/Spa') && getAppSpecific('Above ground?') == 'Yes' && !feeExists('BLDPOOL010', 'NEW') && !feeExists('BLDPOOL010', 'INVOICED') && !feeExists('BLDPOOL020', 'NEW')  && !feeExists('BLDPOOL020', 'INVOICED') ^ addFee('BLDPOOL010', 'BUILDING', '2008.Q4', 1, 'N'); addFee('BLDPOOL020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Pool Type'), 'Pool/Spa') && getAppSpecific('Above ground?') != 'Yes' && !feeExists('BLDPOOL010', 'NEW') && !feeExists('BLDPOOL010', 'INVOICED') && !feeExists('BLDPOOL025', 'NEW') && !feeExists('BLDPOOL025', 'INVOICED') ^ addFee('BLDPOOL010', 'BUILDING', '2008.Q4', 1, 'N'); addFee('BLDPOOL025', 'BUILDING', 'FY 13-14', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_POOL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Standard Plan on File') != 'Yes' && !feeExists('BLDPOOL040', 'NEW') && !feeExists('BLDPOOL040', 'INVOICED') ^ addFee('BLDPOOL040', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/18/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_RES_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/18/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('BLDSUBRES010', 'NEW') && !feeExists('BLDSUBRES010', 'INVOICED') && matches(getAppSpecific('Project Type'), 'Custom Home') ^ addFee('BLDSUBRES010', 'BUILDING', 'FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "getAppSpecific('Sanitation development') == 'CHECKED' && !feeExists('BLDDEV800', 'NEW') && !feeExists('BLDDEV800','INVOICED') ^ addFee('BLDDEV800', 'BUILDING', 'FY 11-12', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Transportation development') == 'CHECKED' && !feeExists('BLDDEV810', 'NEW') && !feeExists('BLDDEV810','INVOICED') ^ addFee('BLDDEV810', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Police facilities development') == 'CHECKED' && !feeExists('BLDDEV820', 'NEW') && !feeExists('BLDDEV820','INVOICED') ^ addFee('BLDDEV820', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire facilities development') == 'CHECKED' && !feeExists('BLDDEV830', 'NEW') && !feeExists('BLDDEV830','INVOICED') ^ addFee('BLDDEV830', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('General government development') == 'CHECKED' && !feeExists('BLDDEV840', 'NEW') && !feeExists('BLDDEV840','INVOICED') ^ addFee('BLDDEV840', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Parks development') == 'CHECKED' && !feeExists('BLDDEV850', 'NEW') && !feeExists('BLDDEV850','INVOICED') ^ addFee('BLDDEV850', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Library development') == 'CHECKED' && !feeExists('BLDDEV860', 'NEW') && !feeExists('BLDDEV860','INVOICED') ^ addFee('BLDDEV860', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV810') && !feeExists('BLDINFL010', 'NEW') && !feeExists('BLDINFL010', 'INVOICED') ^ addFee('BLDINFL010', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV810'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV820') && !feeExists('BLDINFL020', 'NEW') && !feeExists('BLDINFL020', 'INVOICED') ^ addFee('BLDINFL020', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV820'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV830') && !feeExists('BLDINFL030', 'NEW') && !feeExists('BLDINFL030', 'INVOICED') ^ addFee('BLDINFL030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV830'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV840') && !feeExists('BLDINFL040', 'NEW') && !feeExists('BLDINFL040', 'INVOICED') ^ addFee('BLDINFL040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV840'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV850') && !feeExists('BLDINFL060', 'NEW') && !feeExists('BLDINFL060', 'INVOICED') ^ addFee('BLDINFL060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV850'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV860') && !feeExists('BLDINFL050', 'NEW') && !feeExists('BLDINFL050', 'INVOICED') ^ addFee('BLDINFL050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV860'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; branch('REMVOVE_ESTIMATE_FEES'); varX = getValCalc();varY=getValMul();"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MTR_RES_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_ELEC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MECH_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_PLMB_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_RES_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('BLDPERMIT100', 'NEW') && !feeExists('BLDPERMIT100', 'INVOICED') ^ addFee('BLDPERMIT010', 'BUILDING', '2008.Q4', varX, 'N');varFA=feeAmount('BLDPERMIT010');addFee( 'BLDPERMIT100','BUILDING','2008.Q4',varFA*varY, 'N');removeFee('BLDPERMIT010', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT100') && !feeExists('BLDPLNREV070', 'NEW') && !feeExists('BLDPLNREV070', 'INVOICED') ^ addFee('BLDPLNREV070', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Fire Sprinklers'), 'Yes') && !feeExists('BLDFSPK010', 'NEW') && !feeExists('BLDFSPK010', 'INVOICED') ^ addFee( 'BLDFSPK010','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_OCCUPANCY_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_RES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDSUBRES010') && !feeExists('BLDSUBREF010', 'NEW') && !feeExists('BLDSUBREF010', 'INVOICED') ^ addFee( 'BLDSUBREF010','BUILDING','FY 13-14', -feeAmount('BLDSUBRES010','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_REV_PLANS_BEFORE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;"
	}, {
		"BIZDOMAIN" : "BLD_REV_PLANS_BEFORE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Approval') && wfStatus.equals('Approved') && balanceDue != 0 && getAppSpecific('Issue Approval without full payment') != 'Yes' ^ comment('Can not issue plans. The balance has to be 0. Current balance is - ' + balanceDue);cancel=true;"
	}, {
		"BIZDOMAIN" : "BLD_REV_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/25/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_REV_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/25/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Commercial Water Meter') ^ branch('BLD_MTR_REVC_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_REV_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/25/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Project Type'), 'Water Meter') ^ branch('BLD_MTR_REVR_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_REV_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/25/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Building Plan Review Fee') > 0 && !feeExists('BLDPLNREV100', 'NEW') && !feeExists('BLDPLNREV100', 'INVOICED') ^ addFee('BLDPLNREV100','BUILDING','2008.Q4', getAppSpecific('Building Plan Review Fee'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SCHL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_SCHL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Elementary School') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV270', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV270');addFee( 'BLDDVM010','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV270', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_SCHL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Middle School') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV280', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV280');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV280', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_SCHL_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "2/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'High School') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV290', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV290');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV290', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_SFD_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/29/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = false;"
	}, {
		"BIZDOMAIN" : "BLD_SFD_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/29/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('BLDSUBSFD010') ^ addFee('BLDSUBSFD010', 'BUILDING', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "getAppSpecific('Sanitation development') == 'CHECKED' ^ addFee('BLDDEV800', 'BUILDING', 'FY 11-12', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Transportation development') == 'CHECKED' ^ addFee('BLDDEV810', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Police facilities development') == 'CHECKED' ^ addFee('BLDDEV820', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire facilities development') == 'CHECKED' ^ addFee('BLDDEV830', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('General government development') == 'CHECKED' ^ addFee('BLDDEV840', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Parks development') == 'CHECKED' ^ addFee('BLDDEV850', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Library development') == 'CHECKED' ^ addFee('BLDDEV860', 'BUILDING', 'FY 14-15', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV810') && !feeExists('BLDINFL010', 'NEW') && !feeExists('BLDINFL010', 'INVOICED') ^ addFee('BLDINFL010', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV810'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV820') && !feeExists('BLDINFL020', 'NEW') && !feeExists('BLDINFL020', 'INVOICED') ^ addFee('BLDINFL020', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV820'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV830') && !feeExists('BLDINFL030', 'NEW') && !feeExists('BLDINFL030', 'INVOICED') ^ addFee('BLDINFL030', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV830'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV840') && !feeExists('BLDINFL040', 'NEW') && !feeExists('BLDINFL040', 'INVOICED') ^ addFee('BLDINFL040', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV840'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV850') && !feeExists('BLDINFL060', 'NEW') && !feeExists('BLDINFL060', 'INVOICED') ^ addFee('BLDINFL060', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV850'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_DEV_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "9/1/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Infill') == 'CHECKED' && feeExists('BLDDEV860') && !feeExists('BLDINFL050', 'NEW') && !feeExists('BLDINFL050', 'INVOICED') ^ addFee('BLDINFL050', 'BUILDING', 'FY 14-15', feeAmount('BLDDEV860'), 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; branch('REMVOVE_ESTIMATE_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MTR_SFD_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_ELEC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_MECH_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_PLMB_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_SFD_DEV_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_PTYP_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_OCCUPANCY_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Fire Sprinklers'), 'Yes') && !feeExists('BLDFSPK010', 'NEW') && !feeExists('BLDFSPK010', 'INVOICED') ^ addFee( 'BLDFSPK010','BUILDING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDSUBSFD010') && !feeExists('BLDSUBREF010') ^ addFee( 'BLDSUBREF010','BUILDING','FY 13-14', -feeAmount('BLDSUBSFD010','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^  varX= getValCalc();"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('BLDPERMIT010', 'NEW' ) && !feeExists('BLDPERMIT010', 'INVOICED' ) ^ addFee('BLDPERMIT010', 'BUILDING', '2008.Q4', varX, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SFD_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDPERMIT010') ^ addFee('BLDPLNREV020', 'BUILDING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "BLD_SP_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/29/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment('BLD_SP_ADD_FEES branch worked!');"
	}, {
		"BIZDOMAIN" : "BLD_SP_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/29/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Plan Type'), 'SFD') && !feeExists('BLDSUBSP010', 'NEW') && !feeExists('BLDSUBSP010', 'INVOICED') ^ addFee('BLDSUBSP010', 'BUILDING', 'FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "BLD_SP_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment('BLD_SP_PRMT_FEES branch worked!');varX = getValCalc();varY=getValMul();"
	}, {
		"BIZDOMAIN" : "BLD_SP_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Plan Type'), 'SFD') && !feeExists('BLDPLNREV040', 'NEW') && !feeExists('BLDPLNREV040', 'INVOICED') ^ addFee('BLDPERMIT010', 'BUILDING', '2008.Q4', varX,'N'); varBld = feeAmount('BLDPERMIT010'); varBld2 = varBld * 0.65; addFee('BLDPLNREV040', 'BUILDING', '2008.Q4', varBld2,'N'); removeFee('BLDPERMIT010', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_SP_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Plan Type'), 'Pool/Spa') && !feeExists('BLDPLNREV050', 'NEW') && !feeExists('BLDPLNREV050', 'INVOICED') ^ addFee('BLDPLNREV050','BUILDING', '2008.Q4', 1,'N');"
	}, {
		"BIZDOMAIN" : "BLD_SP_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('BLDSUBSP010') && !feeExists('BLDSUBREF010', 'NEW') && !feeExists('BLDSUBREF010', 'INVOICED') ^ addFee( 'BLDSUBREF010','BUILDING','FY 13-14', -feeAmount('BLDSUBSP010','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "BLD_WHS_DEV_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/5/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;varX = getAppSpecific('Proposed Sq Ft')/1000;"
	}, {
		"BIZDOMAIN" : "BLD_WHS_DEV_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/5/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Warehousing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM010', 'NEW') && !feeExists('BLDDVM010', 'INVOICED') ^ addFee('BLDDEV400', 'BUILDING', '2008.Q4', 1, 'N');varFA=feeAmount('BLDDEV400');addFee( 'BLDDVM010','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV400', '2008.Q4');"
	}, {
		"BIZDOMAIN" : "BLD_WHS_DEV_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/5/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Warehousing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM020', 'NEW') && !feeExists('BLDDVM020', 'INVOICED') ^ addFee('BLDDEV510', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV510');addFee( 'BLDDVM020','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV510', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_WHS_DEV_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/5/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Warehousing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM030', 'NEW') && !feeExists('BLDDVM030', 'INVOICED') ^ addFee('BLDDEV520', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV520');addFee( 'BLDDVM030','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV520', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_WHS_DEV_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/5/2012",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Dev and Impact Use'), 'Warehousing') && getAppSpecific('Proposed Sq Ft') > 0 && !feeExists('BLDDVM040', 'NEW') && !feeExists('BLDDVM040', 'INVOICED') ^ addFee('BLDDEV530', 'BUILDING', 'FY 11-12', 1, 'N');varFA=feeAmount('BLDDEV530');addFee( 'BLDDVM040','BUILDING','2008.Q4',varFA*varX,'N');removeFee('BLDDEV530', 'FY 11-12');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('BLD_WorkflowTaskUpdateAfter branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Calculate Permit Fees') ^ branch('REMVOVE_ESTIMATE_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && wfStatus.equals('Calculate Submittal Fee') ^ branch('BLD_RES_ADD_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfStatus.equals('Calculate Submittal Fee') ^ branch('BLD_COM_ADD_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && wfStatus.equals('Calculate Submittal Fee') ^ branch('BLD_SP_ADD_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Model Home Complex/*') && wfStatus.equals('Calculate Submittal Fee') ^ branch('BLD_MHC_ADD_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Pool-Spa/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_POOL_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_COM_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_SFD_PRMT_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_RES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Accessory Use/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_AU_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Review/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_REV_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_CODE_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Model Home Complex/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_MHC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ editAppSpecific('Permit Issue Date',dateAdd(null,0));editAppSpecific('Permit Expiration Date',dateAddMonths(null,6));"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && wfStatus.equals('Calculate Permit Fees') ^ branch('BLD_SP_PRMT_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Clear Fees') ^ branch('REMVOVE_ESTIMATE_FEES');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ branch('BLD_EMAIL_AFTER');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskActive('Fire Inspections') && appMatch('Building/Building Safety/Accessory Use/*') && matches(getAppSpecific('Fire Inspection Required'), 'No') ^ branchTask('Fire Inspections','Not Required');activateTask('Inspections');comment('**********IsActive Branch***********');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskActive('Fire Inspections') && appMatch('Building/Building Safety/Residential/*') && matches(getAppSpecific('Fire Inspection Required'), 'No') ^ branchTask('Fire Inspections','Not Required');activateTask('Inspections');comment('**********IsActive Branch***********');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskActive('Fire Inspections') && appMatch('Building/Building Safety/Standard Plan SFD Permit/*') && matches(getAppSpecific('Fire Sprinklers'), 'No') ^ branchTask('Fire Inspections','Not Required');activateTask('Inspections');comment('**********IsActive Branch***********');"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "6/2/2015",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Calculate Permit Fees') && getAppSpecific('Infill') != 'CHECKED' ^ branch('BLD_ECO_INC_FND')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('BLD_WorkflowTaskUpdateBefore branch worked!')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Review Consolidation') && wfStatus.equals('Approved') ^ branch('OVERALL_PLAN_CHECK_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ branch('PERMIT_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Approval') && wfStatus.equals('Approved') ^ branch('PERMIT_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('C of O/ C of C') && wfStatus.equals('Issued') ^ branch('COFOCC_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Review/*') ^ branch('BLD_REV_PLANS_BEFORE')"
	}, {
		"BIZDOMAIN" : "BLD_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "12/1/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ branch('APPLICATION_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Construction Docs';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Soils Report (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Structurals Calculation (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Projects Manual (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Truss Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Manufacturers Specifications (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDAU_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Special Inspection Cert';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Construction Docs';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Construction Docs';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Soils Report (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Structurals Calculation (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Projects Manual (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Truss Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Kitchen Equipment Specification (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Manufacturers Specifications (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Special Inspection Cert';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Sprinkler Cut Sheets (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Alarm Cut Sheets (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDCOM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Hydraulic Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDMHC_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDMHC_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDMHC_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Site Plan';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plot Plans';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Swimming Pool Affidavit';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Authorization letter to use Engineering Standards on file';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDPOOL_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Engineering Standards';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Construction Docs';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Structurals Calculation (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDRES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Truss Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Construction Docs';ASITableArray['Copies'] = '4'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Soils Report (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Structurals Calculation (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Projects Manual (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Truss Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Manufacturers Specifications (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Special Inspection Cert';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Sprinkler Cut Sheets (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Alarm Cut Sheets (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "7/30/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Hydraulic Calculations (Bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSFD_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDSFD_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Valuation and Fee worksheet';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSFD_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plot Plans';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSFD_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Fire Sprinkler Affidavit';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Standard Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Structural Calculations (bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Soils Report (bound)';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "BLDSP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/14/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Trusses (bound) or Truss Waiver';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "COFOCC_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('C of O C of C Issued Before Update Works!!');"
	}, {
		"BIZDOMAIN" : "COFOCC_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "{Updated.Construction Documents CD Received} != 'Yes' ^ comment('Can not issue C of O/C of C unless Construction Documents CD Received is set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "COFOCC_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/25/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "{Updated.Final Building Inspection} != 'Yes' ^ comment('Can not issue C of O/C of C unless Final Building Inspection is set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "ConvertToRealCapAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/18/2014",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "publicUser ^ email('aCounter@avondale.org', 'no-reply@accela.com', 'Record created in ACA', 'Record created in ACA : ' + capIDString);"
	}, {
		"BIZDOMAIN" : "ENG_CALC_DRAINAGE_FEE_AMOUNT",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/5/2008",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ x = ((getasi(Storm Sewer Pipe Onsite) *.80) + getasi(Storm Sewer Pipe Offsite) * .05))"
	}, {
		"BIZDOMAIN" : "ENG_CALC_DRAINAGE_FEE_AMOUNT",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/5/2008",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ addfee('ENGDRN001', 'ENGINEERING', 'Q.2008', X,N);"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_CCRT_PRMT_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Catch Basin, Headwall Onsite') > 0 && !feeExists('ENGCCRT010', 'NEW') && !feeExists('ENGCCRT010', 'INVOICED') ^ addFee('ENGCCRT010', 'ENGINEERING', '2008.Q4', getAppSpecific('Catch Basin, Headwall Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Catch Basin, Headwall Offsite') > 0 && !feeExists('ENGCCRT020', 'NEW') && !feeExists('ENGCCRT020', 'INVOICED') ^ addFee('ENGCCRT020', 'ENGINEERING', '2008.Q4', getAppSpecific('Catch Basin, Headwall Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Scupper Onsite') > 0 && !feeExists('ENGCCRT030', 'NEW') && !feeExists('ENGCCRT030', 'INVOICED') ^ addFee('ENGCCRT030', 'ENGINEERING', '2008.Q4', getAppSpecific('Scupper Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Scupper Offsite') > 0 && !feeExists('ENGCCRT040', 'NEW') && !feeExists('ENGCCRT040', 'INVOICED') ^ addFee('ENGCCRT040', 'ENGINEERING', '2008.Q4', getAppSpecific('Scupper Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Spillway Onsite') > 0 && !feeExists('ENGCCRT050', 'NEW') && !feeExists('ENGCCRT050', 'INVOICED') ^ addFee('ENGCCRT050', 'ENGINEERING', '2008.Q4', getAppSpecific('Spillway Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Spillway Offsite') > 0 && !feeExists('ENGCCRT060', 'NEW') && !feeExists('ENGCCRT060', 'INVOICED') ^ addFee('ENGCCRT060', 'ENGINEERING', '2008.Q4', getAppSpecific('Spillway Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CCRT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Box Culvert') > 0 && !feeExists('ENGCCRT070', 'NEW') && !feeExists('ENGCCRT070', 'INVOICED') ^ addFee('ENGCCRT070', 'ENGINEERING', '2008.Q4', getAppSpecific('Box Culvert'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_CONSTRUCTION_PERMIT_FEE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_CONSTRUCTION_PERMIT_FEE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_CONSTRUCTION_PERMIT_FEE FIRED!');"
	}, {
		"BIZDOMAIN" : "ENG_CONSTRUCTION_PERMIT_FEE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Grading (gross area) Onsite') > 0 && !feeExists('ENGCON001') ^ addFee('ENGCON001', 'ENGINEERING', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "ENG_CONSTRUCTION_PERMIT_FEE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Storm Sewer Pipe Onsite') > 0 && !feeExists('ENGCON002') ^ addFee('ENGCON002', 'ENGINEERING', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "ENG_CONSTRUCTION_PERMIT_FEE",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/9/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_CALC_DRAINAGE_FEE_AMOUNT')"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Storm Sewer Pipe Onsite') > 0 && !feeExists('ENGDRNG010', 'NEW') && !feeExists('ENGDRNG010', 'INVOICED') ^ addFee('ENGDRNG010', 'ENGINEERING', '2008.Q4', getAppSpecific('Storm Sewer Pipe Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Storm Sewer Manhole Onsite') > 0 && !feeExists('ENGDRNG020', 'NEW') && !feeExists('ENGDRNG020', 'INVOICED') ^ addFee('ENGDRNG020', 'ENGINEERING', '2008.Q4', getAppSpecific('Storm Sewer Manhole Onsite'), 'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Underground Storm Water Ret Pipe Onsite') > 0 && !feeExists('ENGDRNG030', 'NEW') && !feeExists('ENGDRNG030', 'INVOICED') ^ addFee('ENGDRNG030', 'ENGINEERING', '2008.Q4', getAppSpecific('Underground Storm Water Ret Pipe Onsite'), 'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Drywell Onsite') > 0 && !feeExists('ENGDRNG040', 'NEW') && !feeExists('ENGDRNG040', 'INVOICED') ^ addFee('ENGDRNG040', 'ENGINEERING', '2008.Q4', getAppSpecific('Drywell Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Storm Sewer Pipe Offsite') > 0 && !feeExists('ENGDRNG050', 'NEW') && !feeExists('ENGDRNG050', 'INVOICED') ^ addFee('ENGDRNG050', 'ENGINEERING', '2008.Q4', getAppSpecific('Storm Sewer Pipe Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Storm Sewer Manhole Offsite') > 0 && !feeExists('ENGDRNG060', 'NEW') && !feeExists('ENGDRNG060', 'INVOICED') ^ addFee('ENGDRNG060', 'ENGINEERING', '2008.Q4', getAppSpecific('Storm Sewer Manhole Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Rip Rap') > 0 && !feeExists('ENGDRNG070', 'NEW') && !feeExists('ENGDRNG070', 'INVOICED') ^ addFee('ENGDRNG070', 'ENGINEERING', '2008.Q4', getAppSpecific('Rip Rap'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Curb Opening') > 0 && !feeExists('ENGDRNG080', 'NEW') && !feeExists('ENGDRNG080', 'INVOICED') ^ addFee('ENGDRNG080', 'ENGINEERING', '2008.Q4', getAppSpecific('Curb Opening'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***ENG_DRYU_PRMT_FEES branch worked!***')"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Bore Only Offsite') > 0 && !feeExists('ENGDRYU010', 'NEW') && !feeExists('ENGDRYU010', 'INVOICED') ^ addFee('ENGDRYU010', 'ENGINEERING', '2008.Q4', getAppSpecific('Bore Only Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Bore/Splice Pit Offsite') > 0 && !feeExists('ENGDRYU020', 'NEW') && !feeExists('ENGDRYU020', 'INVOICED') ^ addFee('ENGDRYU020', 'ENGINEERING', '2008.Q4', getAppSpecific('Bore/Splice Pit Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pothole Offsite') > 0 && !feeExists('ENGDRYU030', 'NEW') && !feeExists('ENGDRYU030', 'INVOICED') ^ addFee('ENGDRYU030', 'ENGINEERING', '2008.Q4', getAppSpecific('Pothole Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('AC Patch Offsite') > 0 && !feeExists('ENGDRYU040', 'NEW') && !feeExists('ENGDRYU040', 'INVOICED') ^ addFee('ENGDRYU040', 'ENGINEERING', '2008.Q4', getAppSpecific('AC Patch Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Open Trench (RW) Paved Offsite') > 0 && !feeExists('ENGDRYU050', 'NEW') && !feeExists('ENGDRYU050', 'INVOICED') ^ addFee('ENGDRYU050', 'ENGINEERING', '2008.Q4', getAppSpecific('Open Trench (RW) Paved Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_DRYU_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Open Trench (RW) Un-paved Offsite') > 0 && !feeExists('ENGDRYU060', 'NEW') && !feeExists('ENGDRYU060', 'INVOICED') ^ addFee('ENGDRYU060', 'ENGINEERING', '2008.Q4', getAppSpecific('Open Trench (RW) Un-paved Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***ENG_FLTC_PRMT_FEES branch worked!***')"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sidewalk Offsite') > 0 && !feeExists('ENGFLTC010', 'NEW') && !feeExists('ENGFLTC010', 'INVOICED') ^ addFee('ENGFLTC010', 'ENGINEERING', '2008.Q4', getAppSpecific('Sidewalk Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('6 in Vert Curb & Gutter, Single Curb & Ribbon Curb') > 0 && !feeExists('ENGFLTC020', 'NEW') && !feeExists('ENGFLTC020', 'INVOICED') ^ addFee('ENGFLTC020', 'ENGINEERING', '2008.Q4', getAppSpecific('6 in Vert Curb & Gutter, Single Curb & Ribbon Curb'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Valley Gutter & Apron Offsite') > 0 && !feeExists('ENGFLTC030', 'NEW') && !feeExists('ENGFLTC030', 'INVOICED') ^ addFee('ENGFLTC030', 'ENGINEERING', '2008.Q4', getAppSpecific('Valley Gutter & Apron Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Bus Bay, R Turn Lane Offsite') > 0 && !feeExists('ENGFLTC040', 'NEW') && !feeExists('ENGFLTC040', 'INVOICED') ^ addFee('ENGFLTC040', 'ENGINEERING', '2008.Q4', getAppSpecific('Bus Bay, R Turn Lane Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Return Type Driveway (Commercial)Offsite') > 0 && !feeExists('ENGFLTC050', 'NEW') && !feeExists('ENGFLTC050', 'INVOICED') ^ addFee('ENGFLTC050', 'ENGINEERING', '2008.Q4', getAppSpecific('Return Type Driveway (Commercial)Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sidewalk Ramp Offsite') > 0 && !feeExists('ENGFLTC060', 'NEW') && !feeExists('ENGFLTC060', 'INVOICED') ^ addFee('ENGFLTC060', 'ENGINEERING', '2008.Q4', getAppSpecific('Sidewalk Ramp Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_FLTC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Driveway (Non-return Type) Offsite') > 0 && !feeExists('ENGFLTC070', 'NEW') && !feeExists('ENGFLTC070', 'INVOICED') ^ addFee('ENGFLTC070', 'ENGINEERING', '2008.Q4', getAppSpecific('Driveway (Non-return Type) Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_GRDG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/29/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_GRDG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/29/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_GRDG_PRMT_FEES Branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_GRDG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/29/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Grading (gross area) Onsite') > 0 && !feeExists('ENGGRDG010') ^ addFee('ENGGRDG010', 'ENGINEERING', '2008.Q4', getAppSpecific('Grading (gross area) Onsite'), 'N');"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***ENG_IRRG_PRMT_FEES branch worked!***')"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Irrigation Pipe Onsite') > 0 && !feeExists('ENGIRRG010', 'NEW') && !feeExists('ENGIRRG010', 'INVOICED') ^ addFee('ENGIRRG010', 'ENGINEERING', '2008.Q4', getAppSpecific('Irrigation Pipe Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Irrigation Pipe Offsite') > 0 && !feeExists('ENGIRRG020', 'NEW') && !feeExists('ENGIRRG020', 'INVOICED') ^ addFee('ENGIRRG020', 'ENGINEERING', '2008.Q4', getAppSpecific('Irrigation Pipe Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Irrigation Manhole/Structure Onsite') > 0 && !feeExists('ENGIRRG030', 'NEW') && !feeExists('ENGIRRG030', 'INVOICED') ^ addFee('ENGIRRG030', 'ENGINEERING', '2008.Q4', getAppSpecific('Irrigation Manhole/Structure Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_IRRG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Irrigation Manhole/Structure Offsite') > 0 && !feeExists('ENGIRRG040', 'NEW') && !feeExists('ENGIRRG040', 'INVOICED') ^ addFee('ENGIRRG040', 'ENGINEERING', '2008.Q4', getAppSpecific('Irrigation Manhole/Structure Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_LDSC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_LDSC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_LDSC_PRMT_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_LDSC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Landscaping ROW Area Offsite') > 0 && !feeExists('ENGLDSC010', 'NEW') && !feeExists('ENGLDSC010', 'INVOICED') ^ addFee('ENGLDSC010', 'ENGINEERING', '2008.Q4', getAppSpecific('Landscaping ROW Area Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_LDSC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Landscape Backflow Preventor Onsite') > 0 && !feeExists('ENGLDSC020', 'NEW') && !feeExists('ENGLDSC020', 'INVOICED') ^ addFee('ENGLDSC020', 'ENGINEERING', '2008.Q4', getAppSpecific('Landscape Backflow Preventor Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_MISC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "11/4/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('***MISC FEES***')"
	}, {
		"BIZDOMAIN" : "ENG_MISC_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "11/4/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Unspecified Items') > 0 && !feeExists('ENGMSC010', 'NEW') && !feeExists('ENGMSC010', 'INVOICED') ^ addFee('ENGMSC010', 'ENGINEERING', '2008.Q4', getAppSpecific('Unspecified Items'), 'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_PVNG_PRMT_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Conc Asphalt Pavement (Full Section) Offsite') > 0 && !feeExists('ENGPVNG010', 'NEW') && !feeExists('ENGPVNG010', 'INVOICED') ^ addFee('ENGPVNG010', 'ENGINEERING', '2008.Q4', getAppSpecific('New Conc Asphalt Pavement (Full Section) Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Asphalt Pavement Replacement / Utility Cuts') > 0 && !feeExists('ENGPVNG100', 'NEW') && !feeExists('ENGPVNG100', 'INVOICED') ^ addFee('ENGPVNG100', 'ENGINEERING', '2008.Q4', getAppSpecific('Asphalt Pavement Replacement / Utility Cuts'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Asphalt Concrete Overlay (1 Lift) Offsite') > 0 && !feeExists('ENGPVNG030', 'NEW') && !feeExists('ENGPVNG030', 'INVOICED') ^ addFee('ENGPVNG030', 'ENGINEERING', '2008.Q4', getAppSpecific('Asphalt Concrete Overlay (1 Lift) Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Survey Monument Offsite') > 0 && !feeExists('ENGPVNG040', 'NEW') && !feeExists('ENGPVNG040', 'INVOICED') ^ addFee('ENGPVNG040', 'ENGINEERING', '2008.Q4', getAppSpecific('Survey Monument Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Street Sign Offsite') > 0 && !feeExists('ENGPVNG050', 'NEW') && !feeExists('ENGPVNG050', 'INVOICED') ^ addFee('ENGPVNG050', 'ENGINEERING', '2008.Q4', getAppSpecific('Street Sign Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Barricade (Guardrail) Offsite') > 0 && !feeExists('ENGPVNG060', 'NEW') && !feeExists('ENGPVNG060', 'INVOICED') ^ addFee('ENGPVNG060', 'ENGINEERING', '2008.Q4', getAppSpecific('Barricade (Guardrail) Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Striping (4 in equiv) Offsite') > 0 && !feeExists('ENGPVNG070', 'NEW') && !feeExists('ENGPVNG070', 'INVOICED') ^ addFee('ENGPVNG070', 'ENGINEERING', '2008.Q4', getAppSpecific('Striping (4 in equiv) Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Paving Utility Adjustment Offsite') > 0 && !feeExists('ENGPVNG080', 'NEW') && !feeExists('ENGPVNG080', 'INVOICED') ^ addFee('ENGPVNG080', 'ENGINEERING', '2008.Q4', getAppSpecific('Paving Utility Adjustment Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Slurry / Micro Seal') > 0 && !feeExists('ENGPVNG090', 'NEW') && !feeExists('ENGPVNG090', 'INVOICED') ^ addFee('ENGPVNG090', 'ENGINEERING', '2008.Q4', getAppSpecific('Slurry / Micro Seal'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_PVNG_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Paving Utility Adjustment Onsite') > 0 && !feeExists('ENGPVNG085', 'NEW') && !feeExists('ENGPVNG085', 'INVOICED') ^ addFee('ENGPVNG085', 'ENGINEERING', '2008.Q4', getAppSpecific('Paving Utility Adjustment Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_DRNG_PRMT_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Main Line Pipe Onsite') > 0 && !feeExists('ENGSANI010', 'NEW') && !feeExists('ENGSANI010', 'INVOICED') ^ addFee('ENGSANI010', 'ENGINEERING', '2008.Q4', getAppSpecific('Main Line Pipe Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Main Line Pipe Offsite') > 0 && !feeExists('ENGSANI020', 'NEW') && !feeExists('ENGSANI020', 'INVOICED') ^ addFee('ENGSANI020', 'ENGINEERING', '2008.Q4', getAppSpecific('Main Line Pipe Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Service Line Pipe Onsite') > 0 && !feeExists('ENGSANI030', 'NEW') && !feeExists('ENGSANI030', 'INVOICED') ^ addFee('ENGSANI030', 'ENGINEERING', '2008.Q4', getAppSpecific('Service Line Pipe Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Service Line Pipe Offsite') > 0 && !feeExists('ENGSANI040', 'NEW') && !feeExists('ENGSANI040', 'INVOICED') ^ addFee('ENGSANI040', 'ENGINEERING', '2008.Q4', getAppSpecific('Service Line Pipe Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Manhole Onsite') > 0 && !feeExists('ENGSANI050', 'NEW') && !feeExists('ENGSANI050', 'INVOICED') ^ addFee('ENGSANI050', 'ENGINEERING', '2008.Q4', getAppSpecific('Manhole Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Manhole Offsite') > 0 && !feeExists('ENGSANI060', 'NEW') && !feeExists('ENGSANI060', 'INVOICED') ^ addFee('ENGSANI060', 'ENGINEERING', '2008.Q4', getAppSpecific('Manhole Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Drop connection Onsite') > 0 && !feeExists('ENGSANI070', 'NEW') && !feeExists('ENGSANI070', 'INVOICED') ^ addFee('ENGSANI070', 'ENGINEERING', '2008.Q4', getAppSpecific('Drop connection Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Drop connection Offsite') > 0 && !feeExists('ENGSANI080', 'NEW') && !feeExists('ENGSANI080', 'INVOICED') ^ addFee('ENGSANI080', 'ENGINEERING', '2008.Q4', getAppSpecific('Drop connection Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Cleanout; mains & service lines Onsite') > 0 && !feeExists('ENGSANI090', 'NEW') && !feeExists('ENGSANI090', 'INVOICED') ^ addFee('ENGSANI090', 'ENGINEERING', '2008.Q4', getAppSpecific('Cleanout; mains & service lines Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Cleanout; mains & service lines Offsite') > 0 && !feeExists('ENGSANI100', 'NEW') && !feeExists('ENGSANI100', 'INVOICED') ^ addFee('ENGSANI100', 'ENGINEERING', '2008.Q4', getAppSpecific('Cleanout; mains & service lines Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sewer Tap Onsite') > 0 && !feeExists('ENGSANI110', 'NEW') && !feeExists('ENGSANI110', 'INVOICED') ^ addFee('ENGSANI110', 'ENGINEERING', '2008.Q4', getAppSpecific('Sewer Tap Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sewer Tap Offsite') > 0 && !feeExists('ENGSANI120', 'NEW') && !feeExists('ENGSANI120', 'INVOICED') ^ addFee('ENGSANI120', 'ENGINEERING', '2008.Q4', getAppSpecific('Sewer Tap Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pipe Connection Onsite') > 0 && !feeExists('ENGSANI130', 'NEW') && !feeExists('ENGSANI130', 'INVOICED') ^ addFee('ENGSANI130', 'ENGINEERING', '2008.Q4', getAppSpecific('Pipe Connection Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pipe Connection Offsite') > 0 && !feeExists('ENGSANI140', 'NEW') && !feeExists('ENGSANI140', 'INVOICED') ^ addFee('ENGSANI140', 'ENGINEERING', '2008.Q4', getAppSpecific('Pipe Connection Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pipe Encasement Onsite') > 0 && !feeExists('ENGSANI150', 'NEW') && !feeExists('ENGSANI150', 'INVOICED') ^ addFee('ENGSANI150', 'ENGINEERING', '2008.Q4', getAppSpecific('Pipe Encasement Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pipe Encasement Offsite') > 0 && !feeExists('ENGSANI160', 'NEW') && !feeExists('ENGSANI160', 'INVOICED') ^ addFee('ENGSANI160', 'ENGINEERING', '2008.Q4', getAppSpecific('Pipe Encasement Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sanitary Sewer Pavement Replacement Offsite') > 0 && !feeExists('ENGSANI170', 'NEW') && !feeExists('ENGSANI170', 'INVOICED') ^ addFee('ENGSANI170', 'ENGINEERING', '2008.Q4', getAppSpecific('Sanitary Sewer Pavement Replacement Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sanitary Sewer Utility Adjustment Onsite') > 0 && !feeExists('ENGSANI180', 'NEW') && !feeExists('ENGSANI180', 'INVOICED') ^ addFee('ENGSANI180', 'ENGINEERING', '2008.Q4', getAppSpecific('Sanitary Sewer Utility Adjustment Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_SANI_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Sanitary Sewer Utility Adjustment Offsite') > 0 && !feeExists('ENGSANI190', 'NEW') && !feeExists('ENGSANI190', 'INVOICED') ^ addFee('ENGSANI190', 'ENGINEERING', '2008.Q4', getAppSpecific('Sanitary Sewer Utility Adjustment Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_STRL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_STRL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('ENG_STRL_PRMT_FEES branch worked!')"
	}, {
		"BIZDOMAIN" : "ENG_STRL_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/16/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Street Light Offsite') > 0 && !feeExists('ENGSTRL010', 'NEW') && !feeExists('ENGSTRL010', 'INVOICED') ^ addFee('ENGSTRL010', 'ENGINEERING', '2008.Q4', getAppSpecific('Street Light Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_UTILITY_ADD_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/5/2008",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_UTILITY_ADD_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/5/2008",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch ('ENG_CONSTRUCTION_PERMIT_FEE');"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; ^ comment('***ENG_UTLY_PRMT_FEES branch worked!***')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_MISC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_GRDG_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_DRNG_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_IRRG_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_SANI_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_WTR_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_DRYU_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_CCRT_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_FLTC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_PVNG_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_STRL_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('ENG_LDSC_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') && getAppSpecific('No Charge for Utility Permit') == 'CHECKED' && !feeExists('ENGUTL010', 'NEW') && !feeExists('ENGUTL010', 'INVOICED') ^ addFee('ENGUTL010', 'ENGINEERING', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "ENG_UTLY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "7/21/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') && getAppSpecific('CIP No Charge for Utility Permit') == 'CHECKED' && !feeExists('ENGUTL020', 'NEW') && !feeExists('ENGUTL020', 'INVOICED') ^ addFee('ENGUTL020', 'ENGINEERING', 'FY 11-12', 0, 'N');"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Calculate Permit Fees') ^ branch('ENG_UTLY_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Clear Fees') ^ branch('REMVOVE_ESTIMATE_FEES');"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') && wfTask.equals('Acceptance') && wfStatus.equals('Final Acceptance') ^ editTaskDueDate('Warranty Inspections',dateAddMonths(null,11));"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') && !appMatch('Building/Civil Engineering/Floodplain/*') ^ editAppSpecific('Permit Issue Date',dateAdd(null,0));editAppSpecific('Permit Expiration Date',dateAddMonths(null,12));"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') && appMatch('Building/Civil Engineering/Floodplain/*') ^ editAppSpecific('Permit Issue Date',dateAdd(null,0));editAppSpecific('Permit Expiration Date',dateAddMonths(null,6));"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***ENG_WorkflowTaskUpdateBefore Works!***');"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved') ^ branch('OVERALL_PLAN_CHECK_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "ENG_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/28/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ branch('PERMIT_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***ENG_WTR_PRMT_FEES branch worked!***')"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Main Line Onsite') > 0 && !feeExists('ENGWTR010', 'NEW') && !feeExists('ENGWTR010', 'INVOICED') ^ addFee('ENGWTR010', 'ENGINEERING', '2008.Q4', getAppSpecific('Main Line Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Main Line Offsite') > 0 && !feeExists('ENGWTR020', 'NEW') && !feeExists('ENGWTR020', 'INVOICED') ^ addFee('ENGWTR020', 'ENGINEERING', '2008.Q4', getAppSpecific('Main Line Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Service Line Offsite') > 0 && !feeExists('ENGWTR030', 'NEW') && !feeExists('ENGWTR030', 'INVOICED') ^ addFee('ENGWTR030', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Service Line Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Tapping Sleeve Onsite') > 0 && !feeExists('ENGWTR040', 'NEW') && !feeExists('ENGWTR040', 'INVOICED') ^ addFee('ENGWTR040', 'ENGINEERING', '2008.Q4', getAppSpecific('Tapping Sleeve Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Tapping Sleeve Offsite') > 0 && !feeExists('ENGWTR050', 'NEW') && !feeExists('ENGWTR050', 'INVOICED') ^ addFee('ENGWTR050', 'ENGINEERING', '2008.Q4', getAppSpecific('Tapping Sleeve Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Mainline/Lateral/FH Valve Onsite') > 0 && !feeExists('ENGWTR060', 'NEW') && !feeExists('ENGWTR060', 'INVOICED') ^ addFee('ENGWTR060', 'ENGINEERING', '2008.Q4', getAppSpecific('Mainline/Lateral/FH Valve Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Mainline/Lateral/FH Valve Offsite') > 0 && !feeExists('ENGWTR070', 'NEW') && !feeExists('ENGWTR070', 'INVOICED') ^ addFee('ENGWTR070', 'ENGINEERING', '2008.Q4', getAppSpecific('Mainline/Lateral/FH Valve Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Valve MH Vault Onsite') > 0 && !feeExists('ENGWTR080', 'NEW') && !feeExists('ENGWTR080', 'INVOICED') ^ addFee('ENGWTR080', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Valve MH Vault Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Valve MH Vault Offsite') > 0 && !feeExists('ENGWTR090', 'NEW') && !feeExists('ENGWTR090', 'INVOICED') ^ addFee('ENGWTR090', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Valve MH Vault Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Line Onsite') > 0 && !feeExists('ENGWTR100', 'NEW') && !feeExists('ENGWTR100', 'INVOICED') ^ addFee('ENGWTR100', 'ENGINEERING', '2008.Q4', getAppSpecific('Fire Line Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Line Offsite') > 0 && !feeExists('ENGWTR110', 'NEW') && !feeExists('ENGWTR110', 'INVOICED') ^ addFee('ENGWTR110', 'ENGINEERING', '2008.Q4', getAppSpecific('Fire Line Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Hydrant Onsite') > 0 && !feeExists('ENGWTR120', 'NEW') && !feeExists('ENGWTR120', 'INVOICED') ^ addFee('ENGWTR120', 'ENGINEERING', '2008.Q4', getAppSpecific('Fire Hydrant Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Hydrant Offsite') > 0 && !feeExists('ENGWTR130', 'NEW') && !feeExists('ENGWTR130', 'INVOICED') ^ addFee('ENGWTR130', 'ENGINEERING', '2008.Q4', getAppSpecific('Fire Hydrant Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Blow Off/Tapped Cap Onsite') > 0 && !feeExists('ENGWTR140', 'NEW') && !feeExists('ENGWTR140', 'INVOICED') ^ addFee('ENGWTR140', 'ENGINEERING', '2008.Q4', getAppSpecific('Blow Off/Tapped Cap Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Blow Off/Tapped Cap Offsite') > 0 && !feeExists('ENGWTR150', 'NEW') && !feeExists('ENGWTR150', 'INVOICED') ^ addFee('ENGWTR150', 'ENGINEERING', '2008.Q4', getAppSpecific('Blow Off/Tapped Cap Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Meter Box Offsite') > 0 && !feeExists('ENGWTR160', 'NEW') && !feeExists('ENGWTR160', 'INVOICED') ^ addFee('ENGWTR160', 'ENGINEERING', '2008.Q4', getAppSpecific('Meter Box Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Backflow Preventor (Up to 3 in.) Onsite') > 0 && !feeExists('ENGWTR170', 'NEW') && !feeExists('ENGWTR170', 'INVOICED') ^ addFee('ENGWTR170', 'ENGINEERING', '2008.Q4', getAppSpecific('Backflow Preventor (Up to 3 in.) Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Line Connection Onsite') > 0 && !feeExists('ENGWTR180', 'NEW') && !feeExists('ENGWTR180', 'INVOICED') ^ addFee('ENGWTR180', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Line Connection Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Line Connection Offsite') > 0 && !feeExists('ENGWTR190', 'NEW') && !feeExists('ENGWTR190', 'INVOICED') ^ addFee('ENGWTR190', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Line Connection Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Pavement Replacement Offsite') > 0 && !feeExists('ENGWTR200', 'NEW') && !feeExists('ENGWTR200', 'INVOICED') ^ addFee('ENGWTR200', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Pavement Replacement Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Utility Adjustment Onsite') > 0 && !feeExists('ENGWTR210', 'NEW') && !feeExists('ENGWTR210', 'INVOICED') ^ addFee('ENGWTR210', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Utility Adjustment Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Water Utility Adjustment Offsite') > 0 && !feeExists('ENGWTR220', 'NEW') && !feeExists('ENGWTR220', 'INVOICED') ^ addFee('ENGWTR220', 'ENGINEERING', '2008.Q4', getAppSpecific('Water Utility Adjustment Offsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENG_WTR_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "5/2/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Backflow Preventor (3 in. & Greater) Onsite') > 0 && !feeExists('ENGWTR230', 'NEW') && !feeExists('ENGWTR230', 'INVOICED') ^ addFee('ENGWTR230', 'ENGINEERING', '2008.Q4', getAppSpecific('Backflow Preventor (3 in. & Greater) Onsite'),'N');"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Approved Letter with Stipulations';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Water') ^ ASITableArray['Document Name'] = 'Water Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Water') ^ ASITableArray['Document Name'] = 'Water Report';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Sewer') ^ ASITableArray['Document Name'] = 'Sewer Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Sewer') ^ ASITableArray['Document Name'] = 'Sewer Report';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Grading and Drainage') ^ ASITableArray['Document Name'] = 'Grading and Drainage Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Grading and Drainage') ^ ASITableArray['Document Name'] = 'Drainage Report';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Grading and Drainage') ^ ASITableArray['Document Name'] = 'Storm Water Management Plan';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Paving') ^ ASITableArray['Document Name'] = 'Paving Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Mass Grading') ^ ASITableArray['Document Name'] = 'Mass Grading Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Street Light Plans') ^ ASITableArray['Document Name'] = 'Street Light Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Traffic Signal') ^ ASITableArray['Document Name'] = 'Traffic Signal Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Signing and Striping') ^ ASITableArray['Document Name'] = 'Signing and Striping Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGIMPROVE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Landscape') ^ ASITableArray['Document Name'] = 'Planning Approved Landscape Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGMAPREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "ENGMAPREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGMAPREV_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Reports(bound)';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGUTILITY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "ENGUTILITY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "ENGUTILITY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FeeAssessAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = false;"
	}, {
		"BIZDOMAIN" : "FeeAssessBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/13/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = false;"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('***FP_ACES_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification - Interior/private fire apparatus access road') > 0 && !feeExists('FPACMD010', 'NEW') && !feeExists('FPACMD010', 'INVOICED') ^ addFee('FPACMD010', 'FIRE', '2008.Q4', getAppSpecific('Modification - Interior/private fire apparatus access road'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Fire lane marking') > 0 && !feeExists('FPACNI020', 'NEW') && !feeExists('FPACNI020', 'INVOICED') ^ addFee('FPACNI020', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Fire lane marking'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Address directory') > 0 && !feeExists('FPACNI030', 'NEW') && !feeExists('FPACNI030', 'INVOICED') ^ addFee('FPACNI030', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Address directory'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Fire apparatus automatic access gate') > 0 && !feeExists('FPACNI040', 'NEW') && !feeExists('FPACNI040', 'INVOICED') ^ addFee('FPACNI040', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Fire apparatus automatic access gate'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Fire apparatus manual access gate') > 0 && !feeExists('FPACNI050', 'NEW') && !feeExists('FPACNI050', 'INVOICED') ^ addFee('FPACNI050', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Fire apparatus manual access gate'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Firefighter access walkway gate') > 0 && !feeExists('FPACNI060', 'NEW') && !feeExists('FPACNI060', 'INVOICED') ^ addFee('FPACNI060', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Firefighter access walkway gate'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Key Box') > 0 && !feeExists('FPACNI070', 'NEW') && !feeExists('FPACNI070', 'INVOICED') ^ addFee('FPACNI070', 'FIRE', '2008.Q4', getAppSpecific('Key Box'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification to Fire Department Access Item') > 0 && !feeExists('FPACMD080', 'NEW') && !feeExists('FPACMD080', 'INVOICED') ^ addFee('FPACMD080', 'FIRE', '2008.Q4', getAppSpecific('Modification to Fire Department Access Item'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Key Switch') > 0 && !feeExists('FPACNI090', 'NEW') && !feeExists('FPACNI090', 'INVOICED') ^ addFee('FPACNI090', 'FIRE', '2008.Q4', getAppSpecific('Key Switch'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Padlock') > 0 && !feeExists('FPACNI100', 'NEW')  && !feeExists('FPACNI100', 'INVOICED') ^ addFee('FPACNI100', 'FIRE', '2008.Q4', getAppSpecific('Padlock'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other') > 0 && !feeExists('FPOTR010', 'NEW') && !feeExists('FPOTR010', 'INVOICED') ^ addFee('FPOTR010', 'FIRE', '2008.Q4',getAppSpecific('Other'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ACES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "4/15/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_ADD_SUB_FEE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/29/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "FP_ADD_SUB_FEE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/29/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('FPSUB010', 'NEW') && !feeExists('FPSUB010','INVOICED') ^ addFee('FPSUB010', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_AFES_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Water') > 0 && !feeExists('FPAFNI010', 'NEW') && !feeExists('FPAFNI010', 'INVOICED') ^ addFee('FPAFNI010', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Water'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Foam') > 0 && !feeExists('FPAFNI020', 'NEW') && !feeExists('FPAFNI020', 'INVOICED') ^ addFee('FPAFNI020', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Foam'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - C02') > 0 && !feeExists('FPAFNI030', 'NEW') && !feeExists('FPAFNI030', 'INVOICED') ^ addFee('FPAFNI030', 'FIRE', '2008.Q4', getAppSpecific('New Installation - C02'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Clean Agent ') > 0 && !feeExists('FPAFNI040', 'NEW') && !feeExists('FPAFNI040', 'INVOICED') ^ addFee('FPAFNI040', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Clean Agent'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation - Halon') > 0 && !feeExists('FPAFNI050', 'NEW') && !feeExists('FPAFNI050', 'INVOICED') ^ addFee('FPAFNI050', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Halon'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "getAppSpecific('New Installation - Chemical') > 0 && !feeExists('FPAFNI060', 'NEW') && !feeExists('FPAFNI060', 'INVOICED') ^ addFee('FPAFNI060', 'FIRE', '2008.Q4', getAppSpecific('New Installation - Chemical'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation commercial cooking - single system') == 'CHECKED' && !feeExists('FPAFNI070', 'NEW') && !feeExists('FPAFNI070', 'INVOICED') ^ addFee('FPAFNI070', 'FIRE', '2008.Q4',1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Additional commercial cooking system installed at the same time') > 0 && !feeExists('FPALNI010', 'NEW') && !feeExists('FPALNI010', 'INVOICED') ^ addFee('FPAFNI080', 'FIRE', '2008.Q4', getAppSpecific('Additional commercial cooking system installed at the same time'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification to Alternative Fire System') > 0 && !feeExists('FPAFNI090', 'NEW') && !feeExists('FPAFNI090', 'INVOICED') ^ addFee('FPAFNI090', 'FIRE', '2008.Q4', getAppSpecific('Modification to Alternative Fire System'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other') > 0 && !feeExists('FPOTR010', 'NEW') && !feeExists('FPOTR010', 'INVOICED') ^ addFee('FPOTR010', 'FIRE', '2008.Q4',getAppSpecific('Other'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_AFES_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "4/14/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment('***FP_ALRM_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation sq ft') > 0 && !feeExists('FPALNI010', 'NEW') && !feeExists('FPALNI010', 'INVOICED')  ^ addFee('FPALNI010', 'FIRE', '2008.Q4',getAppSpecific('New Installation sq ft'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification # of Devices') > 0 && !feeExists('FPALMD010', 'NEW') && !feeExists('FPALMD010', 'INVOICED') ^ addFee('FPALMD010', 'FIRE', '2008.Q4', getAppSpecific('Modification # of Devices'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification, New Fire Alarm Control Panel') > 0  && !feeExists('FPALMD020', 'NEW') && !feeExists('FPALMD020', 'INVOICED') ^ addFee('FPALMD020', 'FIRE', '2008.Q4', getAppSpecific('Modification, New Fire Alarm Control Panel'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Modification, Connection to Access-Controlled Egress Doors or Delayed Egress Locks') == 'CHECKED' && !feeExists('FPALMD030', 'NEW') && !feeExists('FPALMD030', 'INVOICED') ^ addFee('FPALMD030', 'FIRE', '2008.Q4',1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_ALRM_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_CALC_PRMT FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ comment('***FP_ALRM_PRMT_FEES!');"
	}, {
		"BIZDOMAIN" : "FP_CALC_PRMT FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Alarm Permit/*') ^ branch('FP_ALRM_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_CALC_PRMT FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Access/*') ^ branch('FP_ACES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_CODE_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Standpipe - New Installation') > 0 && !feeExists('FPCDNI010', 'NEW') && !feeExists('FPCDNI010', 'INVOICED') ^ addFee('FPCDNI010', 'FIRE', '2008.Q4', getAppSpecific('Standpipe - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Standpipe - Modification') > 0 && !feeExists('FPCDMD020', 'NEW') && !feeExists('FPCDMD020', 'INVOICED') ^ addFee('FPCDMD020', 'FIRE', '2008.Q4', getAppSpecific('Standpipe - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Pump - New Installation') > 0 && !feeExists('FPCDNI030', 'NEW') && !feeExists('FPCDNI030', 'INVOICED') ^ addFee('FPCDNI030', 'FIRE', '2008.Q4', getAppSpecific('Fire Pump - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Pump - Modification') > 0 && !feeExists('FPCDMD040', 'NEW') && !feeExists('FPCDMD040', 'INVOICED') ^ addFee('FPCDMD040', 'FIRE', '2008.Q4', getAppSpecific('Fire Pump - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Private Fire Protection Water Supply System - New Installation') > 0 && !feeExists('FPCDNI050', 'NEW') && !feeExists('FPCDNI050', 'INVOICED') ^ addFee('FPCDNI050', 'FIRE', '2008.Q4', getAppSpecific('Private Fire Protection Water Supply System - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Private Fire Protection Water Supply System - Modification') > 0 && !feeExists('FPCDMD060', 'NEW') && !feeExists('FPCDMD060', 'INVOICED') ^ addFee('FPCDMD060', 'FIRE', '2008.Q4', getAppSpecific('Private Fire Protection Water Supply System - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fire Flow Test') > 0 && !feeExists('FPCDFT070', 'NEW') && !feeExists('FPCDFT070', 'INVOICED') ^ addFee('FPCDFT070', 'FIRE', '2008.Q4', getAppSpecific('Fire Flow Test'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('High-piled Storage Plan') > 0 && !feeExists('FPCDHP080', 'NEW') && !feeExists('FPCDHP080', 'INVOICED') ^ addFee('FPCDHP080', 'FIRE', '2008.Q4', getAppSpecific('High-piled Storage Plan'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Firefighter Air System (FAS)') > 0 && !feeExists('FPCDFS090', 'NEW') && !feeExists('FPCDFS090', 'INVOICED') ^ addFee('FPCDFS090', 'FIRE', '2008.Q4', getAppSpecific('Firefighter Air System (FAS)'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Public Saftety Radio Amplification System') > 0 && !feeExists('FPCDPS100', 'NEW') && !feeExists('FPCDPS100', 'INVOICED') ^ addFee('FPCDPS100', 'FIRE', '2008.Q4', getAppSpecific('Public Saftety Radio Amplification System'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other') > 0 && !feeExists('FPOTR010', 'NEW') && !feeExists('FPOTR010', 'INVOICED') ^ addFee('FPOTR010', 'FIRE', '2008.Q4',getAppSpecific('Other'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW')  !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_CODE_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('***FP_GET branch worked!***')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Alarm Permit/*') ^ branch('FP_ALRM_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Access/*') ^ branch('FP_ACES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Sprinkler Permit/*') ^ branch('FP_SPRK_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Alternative Fire Extinguishing/*') ^ branch('FP_AFES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Code Permit/*') ^ branch('FP_CODE_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Hazardous Material/*') ^ branch('FP_HZMT_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Flammable & Combustable Liquid/*') ^ branch('FP_TANK_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Spraying Operation/*') ^ branch('FP_SPRY_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_GET_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/15/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Temporary Use Permit/*') ^ branch('FP_TUPT_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_HZMT_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('HazMat Container - New Installation') == 'CHECKED' && !feeExists('FPHMNI010', 'NEW') && !feeExists('FPHMNI010', 'INVOICED') ^ addFee('FPHMNI010', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('HazMat Tank - New Installation') == 'CHECKED' && !feeExists('FPHMNI020', 'NEW') && !feeExists('FPHMNI020', 'INVOICED') ^ addFee('FPHMNI020', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('HazMat Process - New Installation') == 'CHECKED' && !feeExists('FPHMNI030', 'NEW') && !feeExists('FPHMNI030', 'INVOICED') ^ addFee('FPHMNI030', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Additional HazMat Container/Tank/Process - New Installation') > 0 && !feeExists('FPHMNI040', 'NEW') && !feeExists('FPHMNI040', 'INVOICED') ^ addFee('FPHMNI040', 'FIRE', '2008.Q4', getAppSpecific('Additional HazMat Container/Tank/Process - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('HazMat Container/Tank/Process - Modification') > 0 && !feeExists('FPHMMD050', 'NEW') && !feeExists('FPHMMD050', 'INVOICED') ^ addFee('FPHMMD050', 'FIRE', '2008.Q4', getAppSpecific('HazMat Container/Tank/Process - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('L-P Pre-filled Portable Cylinders - New Installation') > 0 && !feeExists('FPHMNI060', 'NEW') && !feeExists('FPHMNI060', 'INVOICED') ^ addFee('FPHMNI060', 'FIRE', '2008.Q4', getAppSpecific('L-P Pre-filled Portable Cylinders - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('L-P Storage Container Use or Resale - New Installation') > 0 && !feeExists('FPHMNI070', 'NEW') && !feeExists('FPHMNI070', 'INVOICED') ^ addFee('FPHMNI070', 'FIRE', '2008.Q4', getAppSpecific('L-P Storage Container Use or Resale - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific(' L-P Gas System - New Installation') > 0 && !feeExists('FPHMNI080', 'NEW') && !feeExists('FPHMNI080', 'INVOICED') ^ addFee('FPHMNI080', 'FIRE', '2008.Q4', getAppSpecific('L-P Gas System - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Compressed Gas Under 400 lbs. - New Installation') > 0 && !feeExists('FPHMNI090', 'NEW') && !feeExists('FPHMNI090', 'INVOICED') ^ addFee('FPHMNI090', 'FIRE', '2008.Q4', getAppSpecific('Compressed Gas Under 400 lbs. - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Compressed Gas Over 400 lbs. - New Installation') > 0 && !feeExists('FPHMNI100', 'NEW') && !feeExists('FPHMNI100', 'INVOICED') ^ addFee('FPHMNI100', 'FIRE', '2008.Q4', getAppSpecific('Compressed Gas Over 400 lbs. - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Compressed Gas - Modificaton') > 0 && !feeExists('FPHMMD110', 'NEW') && !feeExists('FPHMMD110', 'INVOICED') ^ addFee('FPHMMD110', 'FIRE', '2008.Q4', getAppSpecific('Compressed Gas - Modificaton'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_HZMT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('***FP_SPRK_PRMT_FEES!***')"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('FPSPNI010', 'NEW') && !feeExists('FPSPNI010', 'INVOICED') && getAppSpecific('(13 & 13R) sq ft') > 0 && matches(getAppSpecific('Application Type'),'New') ^ addFee('FPSPNI010', 'FIRE', '2008.Q4',getAppSpecific('(13 & 13R) sq ft'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('FPSPMD020', 'NEW') && !feeExists('FPSPMD020', 'INVOICED') && getAppSpecific('(13 & 13R) Number of Sprinkler Heads') > 0 && matches(getAppSpecific('Application Type'),'Modification') ^ addFee('FPSPMD020', 'FIRE', '2008.Q4', getAppSpecific('(13 & 13R) Number of Sprinkler Heads'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('New Installation or Modification (13D)') == 'CHECKED' && !feeExists('FPSPMD030', 'NEW') && !feeExists('FPSPMD030', 'INVOICED') ^ addFee('FPSPMD030', 'FIRE', '2008.Q4',1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') && getAppSpecific('Outsource Fee') > 0 ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_SPRY_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Spray Room - New Installation') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPSYNI010', 'FIRE', '2008.Q4', getAppSpecific('Spray Room - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Dip Tank - New Installation') > 0 && !feeExists('FPSYNI020', 'NEW') && !feeExists('FPSYNI020', 'INVOICED') ^ addFee('FPSYNI020', 'FIRE', '2008.Q4', getAppSpecific('Dip Tank - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Booth - New Installation') > 0 && !feeExists('FPSYNI030', 'NEW') && !feeExists('FPSYNI030', 'INVOICED') ^ addFee('FPSYNI030', 'FIRE', '2008.Q4', getAppSpecific('Booth - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Spray Room/Dip Tank/Booth - Modification') > 0 && !feeExists('FPSYNI040', 'NEW') && !feeExists('FPSYNI040', 'INVOICED') ^ addFee('FPSYNI040', 'FIRE', '2008.Q4', getAppSpecific('Spray Room/Dip Tank/Booth - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW')  && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_SPRY_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_TANK_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Tank - New Installation') == 'CHECKED' && !feeExists('FPTKNI010', 'NEW') && !feeExists('FPTKNI010', 'INVOICED') ^ addFee('FPTKNI010', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Additional Tank - New Installation') > 0 && !feeExists('FPTKNI020', 'NEW') && !feeExists('FPTKNI020', 'INVOICED') ^ addFee('FPTKNI020', 'FIRE', '2008.Q4', getAppSpecific('Additional Tank - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Tank - Modification') > 0 && !feeExists('FPTKMD030', 'NEW') && !feeExists('FPTKMD030', 'INVOICED') ^ addFee('FPTKMD030', 'FIRE', '2008.Q4', getAppSpecific('Tank - Modification'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Tank - Removal') > 0 && !feeExists('FPTKRM040', 'NEW') && !feeExists('FPTKRM040', 'INVOICED') ^ addFee('FPTKRM040', 'FIRE', '2008.Q4', getAppSpecific('Tank - Removal'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Additional Tank - Removal') > 0 && !feeExists('FPTKAT050', 'NEW') && !feeExists('FPTKAT050', 'INVOICED') ^ addFee('FPTKAT050', 'FIRE', '2008.Q4', getAppSpecific('Additional Tank - Removal'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fuel Tank for Emergency/Standby Power - New Installation') > 0 && !feeExists('FPTKNI060', 'NEW') && !feeExists('FPTKNI060', 'INVOICED') ^ addFee('FPTKNI060', 'FIRE', '2008.Q4', getAppSpecific('Fuel Tank for Emergency/Standby Power - New Installation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Outsource Fee') > 0 && !feeExists('FPOSR010', 'NEW') && !feeExists('FPOSR010', 'INVOICED') ^ addFee('FPOSR010', 'FIRE', '2008.Q4', getAppSpecific('Outsource Fee'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('FPSUB010') && !feeExists('FPSUBREF010', 'NEW') && !feeExists('FPSUBREF010', 'INVOICED') ^ addFee( 'FPSUBREF010','FIRE','2008.Q4', -feeAmount('FPSUB010', 'INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TANK_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('FP_TUPT_PRMT_FEES!')"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Single Tent Canopy or Membrance Structure') == 'CHECKED' && !feeExists('FPTUMS010', 'NEW') && !feeExists('FPTUMS010', 'INVOICED') ^ addFee('FPTUMS010', 'FIRE', '2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Each additional Tent Canopy or Membrane Structure') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUMS020', 'FIRE', '2008.Q4', getAppSpecific('Each additional Tent Canopy or Membrane Structure'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fireworks Display each') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUFD030', 'FIRE', '2008.Q4', getAppSpecific('Fireworks Display each'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fireworks Display repeat') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUFD040', 'FIRE', '2008.Q4', getAppSpecific('Fireworks Display repeat'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Pyrotechnics') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUPY050', 'FIRE', '2008.Q4', getAppSpecific('Pyrotechnics'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Temporary Access Road') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUTR060', 'FIRE', '2008.Q4', getAppSpecific('Temporary Access Road'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('LP Gas Construction Site Use >100 lbs') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTULG070', 'FIRE', '2008.Q4', getAppSpecific('LP Gas Construction Site Use >100 lbs'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('LP Gas Pulbic Special Event >40 lbs') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTULG080', 'FIRE', '2008.Q4', getAppSpecific('LP Gas Pulbic Special Event >40 lbs'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Carnival') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF090', 'FIRE', '2008.Q4', getAppSpecific('Carnival'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Fair') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF100', 'FIRE', '2008.Q4', getAppSpecific('Fair'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Circus') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF110', 'FIRE', '2008.Q4', getAppSpecific('Circus'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Amusement Building') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF120', 'FIRE', '2008.Q4', getAppSpecific('Amusement Building'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Exhibit') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF130', 'FIRE', '2008.Q4', getAppSpecific('Exhibit'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Trade Show') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUCF140', 'FIRE', '2008.Q4', getAppSpecific('Trade Show'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Open Burning/Bon Fire') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUBF150', 'FIRE', '2008.Q4', getAppSpecific('Open Burning/Bon Fire'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Blasting Site Operation') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUBS160', 'FIRE', '2008.Q4', getAppSpecific('Blasting Site Operation'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('HazMat Annual Permit') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUHM170', 'FIRE', '2008.Q4', getAppSpecific('HazMat Annual Permit'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Annual Inspection') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPTUAI180', 'FIRE', '2008.Q4', getAppSpecific('Annual Inspection'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Other') > 0 && !feeExists('FPSYNI010', 'NEW') && !feeExists('FPSYNI010', 'INVOICED') ^ addFee('FPOTR010', 'FIRE', '2008.Q4',getAppSpecific('Other'), 'N');"
	}, {
		"BIZDOMAIN" : "FP_TUPT_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "3/8/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Administration Fee') == 'CHECKED' && !feeExists('FPADM010', 'NEW') && !feeExists('FPADM010', 'INVOICED') ^ addFee('FPADM010', 'FIRE', '2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('***FP_WorkflowTaskUpdateAfter branch worked!***')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee')  && !appMatch('Building/Fire Prevention/Temporary Use Permit/*') ^ branch('FP_ADD_SUB_FEE');"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Alarm Permit/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Building Staff Review') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Fire Staff Review') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_ALRM_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Sprinkler Permit/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_SPRK_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Alternative Fire Extinguishing/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_AFES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Access/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_ACES_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Code Permit/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_CODE_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Hazardous Material/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_HZMT_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Flammable & Combustable Liquid/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_TANK_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Spraying Operation/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_SPRY_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Temporary Use Permit/*') && ((wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved')) || (wfTask.equals('Overall Plan Check') && wfStatus.equals('Calculate Permit Fees')) || (wfTask.equals('Permit Issuance') && wfStatus.equals('Calculate Permit Fees'))) ^ branch('FP_TUPT_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Clear Fees') ^ branch('REMVOVE_ESTIMATE_FEES');"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ editAppSpecific('Permit Issue Date',dateAdd(null,0));editAppSpecific('Permit Expiration Date',dateAddMonths(null,6));"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "4/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Calculate Permit Fees') ^ branch('FP_GET_PRMT_FEES');"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "10/8/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('Fire WorkflowTaskUpdateBefore Works!!');"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "10/8/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Review Consolidation') && wfStatus.equals('Approved') ^ branch('OVERALL_PLAN_CHECK_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "10/8/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ branch('PERMIT_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "FP_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "10/8/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && getAppSpecific('School Project') != 'Yes' ^ branch('APPLICATION_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "FPACCESS_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPACCESS_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPACCESS_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPACCESS_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPAFES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPAFES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPAFES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPAFES_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPALARM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPALARM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPALARM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPALARM_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPCODE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Hydraulic Calculations';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMIS';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPHAZMAT_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMMP';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMIS';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPREVIEW_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMMP';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMIS';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRAY_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'HMMP';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPSPRINK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Sprinkler Calculation';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTANK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPTANK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTANK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTANK_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/31/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed Application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plans';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Cut Sheets';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "FPTUP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "8/3/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Other';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "InspectionScheduleAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/18/2014",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "currentUserID.indexOf('PUBLICUSER') == 0 ^ emailEveryone('Inspection Scheduled', 'An Inspection of type ' + inspType + ' has been scheduled for permit ' + capIDString + ' on ' + inspSchedDate + '.');"
	}, {
		"BIZDOMAIN" : "InspectionScheduleBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "InspectionScheduleBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "inspType.equals('Framing') &&  !checkInspectionResult('Rough Fire Sprinkler (fire)','Passed') && matches(getAppSpecific('Fire Sprinklers'), 'Yes') ^ comment('***Can not allow Framing Inspection until Rough Sprinkler Inspection is Passed***'); cancel=true;"
	}, {
		"BIZDOMAIN" : "InspectionScheduleBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/20/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "inspType.equals('Final Electrical Clearance') &&  !checkInspectionResult('Final Fire Sprinkler (fire)','Passed') && matches(getAppSpecific('Fire Sprinklers'), 'Yes') ^ comment'***Can not allow Framing Inspection until Rough Sprinkler Inspection is Passed***'); cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('OVERALL PALN CHECK BEFORE UPDATE***')"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved') || isTaskStatus('EPR Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Model Home Complex/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved') || isTaskStatus('EPR Staff Review','Not Approved') || isTaskStatus('DSC Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('DSC Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Accessory Use/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Pool-Spa/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('DSC Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Review/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('DSC Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && (isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') && (isTaskStatus('Engineering Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Traffic Staff Review','Not Approved') || isTaskStatus('EPR Staff Review','Not Approved') || isTaskStatus('Water Resources Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') && (isTaskStatus('Engineering Staff Review','Not Approved') || isTaskStatus('EPR Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Alternative Fire Extinguishing/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Access/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Alarm Permit/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Code Permit/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Fire Sprinkler Permit/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Flammable & Combustable Liquid/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Hazardous Material/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Spraying Operation/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Technical Assistance Review/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Temporary Use Permit/*') && (isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Building Staff Review','Not Approved')) ^ comment('Overall Paln Check can not be approved if there are any Plan Reviews not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('License Verified') != 'Yes' && (appMatch('Building/Building Safety/Commercial Buildings/*') || appMatch('Building/Building Safety/Residential/*') || appMatch('Building/Building Safety/Code/*') || appMatch('Building/Building Safety/Accessory Use/*') || appMatch('Building/Building Safety/Pool-Spa/*') || appMatch('Building/Building Safety/Standard Plan SFD Permit/*')) ^ comment('Can not Approve if License Verified is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('License Verified') != 'Yes' && (appMatch('Building/Fire Prevention/*/*') && !appMatch('Building/Fire Prevention/Technical Assistance Review/*')) ^ comment('Can not Approve if License Verified is not set to Yes');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskStatus('Building Staff Review','Not Approved') || isTaskStatus('Fire Staff Review','Not Approved') || isTaskStatus('Planning Staff Review','Not Approved') || isTaskStatus('Engineering Staff Review','Not Approved') ^ comment('Parent Task can not be approved if there are any sub tasks that are not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskStatus('Traffic Staff Review','Not Approved') || isTaskStatus('DSC Staff Review','Not Approved') || isTaskStatus('GIS Staff Review','Not Approved') || isTaskStatus('Water Resources Review','Not Approved') || isTaskStatus('Police Staff Review','Not Approved') ^ comment('Parent Task can not be approved if there are any sub tasks that are not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 26,
		"BIZDOMAIN_VALUE2" : "A26",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskStatus('Field Operations Review','Not Approved') || isTaskStatus('Economic Devlopment Director','Not Approved') || isTaskStatus('Engineering Release','Not Approved') || isTaskStatus('Planning Manager','Not Approved') ^ comment('Parent Task can not be approved if there are any sub tasks that are not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "OVERALL_PLAN_CHECK_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 27,
		"BIZDOMAIN_VALUE2" : "A27",
		"REC_DATE" : "3/10/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "isTaskStatus('Engineering Sign Off','Not Approved') || isTaskStatus('Business License Sign Off','Not Approved') || isTaskStatus('Planning Sign Off','Not Approved') || isTaskStatus('Fire Sign Off','Not Approved') || isTaskStatus('Engineering Release','Not Approved') ^ comment('Parent Task can not be approved if there are any sub tasks that are not approved');cancel=true;"
	}, {
		"BIZDOMAIN" : "PaymentReceiveAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/18/2014",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "publicUser ^ email('aCounter@avondale.org', 'no-reply@avondale.org', 'Fees paid in ACA', 'Fees paid on : ' + capIDString);"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***Permit Issued Before Update Works!!***');"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') ^ branch('BLD_COM_PERMIT_BEFORE')"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Residential/*') ^ branch('BLD_RES_PERMIT_BEFORE')"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Review/*') ^ branch('BLD_REV_PERMIT_BEFORE')"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') && !appMatch('Building/Civil Engineering/Floodplain/*') ^ branch('BLD_ENG_PERMIT_BEFORE')"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ arrayFees = aa.fee.getFeeItems(capId).getOutput();"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [comment('This Fee has not been Invoiced - ' + arrayFees[x].getFeeDescription())];"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) if(arrayFees[x].getFeeitemStatus() == 'NEW') [cancel=true];"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "arrayFees.length < 1 && getAppSpecific('School Project') != 'Yes' && !appMatch('Building/Civil Engineering/Floodplain/*') ^ comment('No fees are added. Please recalculate the fees');cancel=true;"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' && getAppSpecific('School Project') != 'Yes' ^ comment('Can not issue permit. The balance has to be 0. Current balance is - ' + balanceDue);cancel=true;"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Civil Engineering/*') && wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') && balanceDue != 0 && !appMatch('Building/Civil Engineering/Floodplain/*') ^ comment('Can not issue permit. The balance has to be 0. Current balance is - ' + balanceDue);cancel=true;"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Approval') && wfStatus.equals('Approved') && balanceDue != 0 && getAppSpecific('Proceed Without Full Payment') != 'Yes' ^ comment('Can not approve. The balance has to be 0. Current balance is - ' + balanceDue);cancel=true;"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***Number of Fees***'+ arrayFees.length)"
	}, {
		"BIZDOMAIN" : "PERMIT_ISSUED_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "getAppSpecific('Project in the Floodplain?') == 'Yes' && matches(getAppSpecific('Floodplain Construction Permit Issue Date'),null) ^ comment('Can not Approve if Floodplain is set to Yes and Floodplain Date is Blank');cancel=true;"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Group Homes') && !feeExists('PLNADM010', 'NEW') && !feeExists('PLNADM010', 'INVOICED') ^ addFee( 'PLNADM010','PLANNING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Zoning Verification') && !feeExists('PLNADM020', 'NEW') && !feeExists('PLNADM020', 'INVOICED') ^ addFee( 'PLNADM020','PLANNING','FY 13-14', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Zoning Interpretation') && !feeExists('PLNADM030', 'NEW') && !feeExists('PLNADM030', 'INVOICED') ^ addFee( 'PLNADM030','PLANNING','FY 13-14', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Manufactured/Modular Building') && !feeExists('PLNADM040', 'NEW') && !feeExists('PLNADM040', 'INVOICED') ^ addFee( 'PLNADM040','PLANNING','2008.Q4', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "PLN_ADM_SUB_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Medical Marijuana') && !feeExists('PLNADM050', 'NEW') && !feeExists('PLNADM050', 'INVOICED') ^ addFee( 'PLNADM050','PLANNING','FY 13-14', 1 , 'N');"
	}, {
		"BIZDOMAIN" : "PLN_COU_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_COU_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Conditional Use Permit') && !feeExists('PLNCON010', 'NEW') && !feeExists('PLNCON010', 'INVOICED') ^ addFee('PLNCON010','PLANNING','FY 13-14',1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_COU_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Unauthorized Use') && !feeExists('PLNCON020', 'NEW') && !feeExists('PLNCON020', 'INVOICED') ^ addFee('PLNCON020','PLANNING','FY 13-14',1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_COU_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'CUP Extension') && !feeExists('PLNCON030', 'NEW') && !feeExists('PLNCON030', 'INVOICED')^ addFee('PLNCON010','PLANNING','FY 13-14',1, 'N');varFA=feeAmount('PLNCON010'); comment('varFA = ' + varFA);addFee( 'PLNCON030','PLANNING','FY 13-14',varFA*.5, 'N');removeFee('PLNCON010', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_COU_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/15/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'CUP Extension Unauthorized Use') && !feeExists('PLNCON040', 'NEW') && !feeExists('PLNCON040', 'INVOICED') ^ addFee('PLNCON020','PLANNING','FY 13-14',1, 'N');varFA=feeAmount('PLNCON020'); comment('varFA = ' + varFA);addFee( 'PLNCON040','PLANNING','FY 13-14',varFA*.5, 'N');removeFee('PLNCON020', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_GEN_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('PLN_GEN_SUB_FEES Worked!')"
	}, {
		"BIZDOMAIN" : "PLN_GEN_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Text/Map'), 'Map') && !feeExists('PLNGEN010', 'NEW') && !feeExists('PLNGEN010', 'INVOICED') ^ addFee( 'PLNGEN010','PLANNING','2008.Q4', getAppSpecific('# of Acres'),'N');"
	}, {
		"BIZDOMAIN" : "PLN_GEN_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Text/Map'), 'Text') && !feeExists('PLNGEN020', 'NEW') && !feeExists('PLNGEN020', 'INVOICED') ^ addFee( 'PLNGEN020','PLANNING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_HSE_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/29/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('PLN_HSE_SUB_FEES Worked!')"
	}, {
		"BIZDOMAIN" : "PLN_HSE_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/29/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('PLNHSE010', 'NEW') && !feeExists('PLNHSE010', 'INVOICED') ^ addFee( 'PLNHSE010','PLANNING','2008.Q4',getAppSpecific('Number of Lots'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('PLN_PLT_SUB_FEES Worked!')"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Preliminary Plat') && !feeExists('PLNPLT010', 'NEW') && !feeExists('PLNPLT010', 'INVOICED') ^ addFee('PLNPLT010','PLANNING','FY 13-14',getAppSpecific('# of lots'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Final Plat') && !feeExists('PLNPLT040', 'NEW') && !feeExists('PLNPLT040', 'INVOICED') ^ addFee('PLNPLT040','PLANNING','FY 13-14',getAppSpecific('# of lots'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Minor Land Division') && !feeExists('PLNPLT060', 'NEW') && !feeExists('PLNPLT060', 'INVOICED') ^ addFee('PLNPLT060','PLANNING','FY 13-14',1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Map of Dedication') && !feeExists('PLNPLT070', 'NEW') && !feeExists('PLNPLT070', 'INVOICED') ^ addFee('PLNPLT070','PLANNING','FY 13-14',1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Preliminary Plat Extension') && !feeExists('PLNPLT020', 'NEW') && !feeExists('PLNPLT020', 'INVOICED') ^ addFee('PLNPLT010','PLANNING','FY 13-14',getAppSpecific('# of lots'), 'N');varFA=feeAmount('PLNPLT010'); comment('varFA = ' + varFA);addFee( 'PLNPLT020','PLANNING','FY 13-14',varFA*.5, 'N');removeFee('PLNPLT010', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Preliminary Plat Amendment') && !feeExists('PLNPLT030', 'NEW') && !feeExists('PLNPLT030', 'INVOICED') ^ addFee('PLNPLT010','PLANNING','FY 13-14',getAppSpecific('# of lots'), 'N');varFA=feeAmount('PLNPLT010'); comment('varFA = ' + varFA);addFee( 'PLNPLT030','PLANNING','FY 13-14',varFA*.5, 'N');removeFee('PLNPLT010', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Final Plat Amendment') && !feeExists('PLNPLT050', 'NEW') && !feeExists('PLNPLT050', 'INVOICED') ^ addFee('PLNPLT040','PLANNING','FY 13-14',getAppSpecific('# of lots'), 'N');varFA=feeAmount('PLNPLT040'); comment('varFA = ' + varFA);addFee( 'PLNPLT050','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNPLT040', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_PLT_SUB_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/14/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('# of lots') > 0 && !feeExists('PLNPLT080', 'NEW') && !feeExists('PLNPLT080', 'INVOICED') ^ addFee('PLNPLT080','PLANNING','FY 14-15',getAppSpecific('# of lots'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PRE_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; true ^ comment('PLN_PRE_SUB_FEES Worked!')"
	}, {
		"BIZDOMAIN" : "PLN_PRE_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Planner') && !feeExists('PLNPRE010', 'NEW') && !feeExists('PLNPRE010', 'INVOICED') ^ addFee( 'PLNPRE010','PLANNING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_PRE_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Team') && !feeExists('PLNPRE020', 'NEW') && !feeExists('PLNPRE020', 'INVOICED') ^ addFee( 'PLNPRE020','PLANNING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Rezoning Single Family') && !feeExists('PLNREZ010', 'NEW') && !feeExists('PLNREZ010', 'INVOICED') ^ addFee( 'PLNREZ010','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Rezoning Multi Family') && !feeExists('PLNREZ020', 'NEW') && !feeExists('PLNREZ020', 'INVOICED') ^ addFee( 'PLNREZ020','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Rezoning Non Residential') && !feeExists('PLNREZ030', 'NEW') && !feeExists('PLNREZ030', 'INVOICED') ^ addFee( 'PLNREZ030','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Rezoning PAD') && !feeExists('PLNREZ040', 'NEW') && !feeExists('PLNREZ040', 'INVOICED') ^ addFee( 'PLNREZ040','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Rezoning CC (City Center)') && !feeExists('PLNREZ050', 'NEW') && !feeExists('PLNREZ050', 'INVOICED') ^ addFee( 'PLNREZ050','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Zoning Ordiance Text Amendment') && !feeExists('PLNREZ060', 'NEW') && !feeExists('PLNREZ060', 'INVOICED') ^ addFee( 'PLNREZ060','PLANNING','FY 13-14',1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Special Use Overlay District') && !feeExists('PLNREZ070', 'NEW') && !feeExists('PLNREZ070', 'INVOICED') ^ addFee( 'PLNREZ070','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'PAD Extension') && !feeExists('PLNREZ080', 'NEW') && !feeExists('PLNREZ080', 'INVOICED') ^ addFee('PLNREZ040','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNREZ040'); comment('varFA = ' + varFA);addFee( 'PLNREZ080','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNREZ040', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'PAD Amendment') && matches(getAppSpecific('Description'), 'Major') && !feeExists('PLNREZ090', 'NEW') && !feeExists('PLNREZ090', 'INVOICED') ^ addFee('PLNREZ040','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNREZ040'); comment('varFA = ' + varFA);addFee( 'PLNREZ090','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNREZ040', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'PAD Amendment') && matches(getAppSpecific('Description'), 'Minor') && !feeExists('PLNREZ100', 'NEW') && !feeExists('PLNREZ100', 'INVOICED') ^ addFee('PLNREZ040','PLANNING','FY 11-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNREZ040'); comment('varFA = ' + varFA);addFee( 'PLNREZ100','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNREZ040', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Special Use Overlay District Extension') && !feeExists('PLNREZ110', 'NEW') && !feeExists('PLNREZ110', 'INVOICED') ^ addFee('PLNREZ070','PLANNING','FY 13-14',1, 'N');varFA=feeAmount('PLNREZ070'); comment('varFA = ' + varFA);addFee( 'PLNREZ110','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNREZ070', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_REZ_SUB_FEES",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/17/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'MESD District') && !feeExists('PLNREZ120', 'NEW') && !feeExists('PLNREZ120', 'INVOICED') ^ addFee( 'PLNREZ120','PLANNING','FY 13-14', getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_RLF_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "2/4/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_RLF_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "2/4/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Use Type'), 'Residential') && !feeExists('PLNRLF010', 'NEW') && !feeExists('PLNRLF010', 'INVOICED') ^ addFee( 'PLNRLF010','PLANNING','FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_RLF_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "2/4/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Use Type'), 'Non-Residential') && !feeExists('PLNRLF020', 'NEW') && !feeExists('PLNRLF020', 'INVOICED') ^ addFee( 'PLNRLF020','PLANNING','FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_SGN_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment('**SIGN PERMIT FEES WORKED**')"
	}, {
		"BIZDOMAIN" : "PLN_SGN_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Permanent') && !feeExists('PLNSGN010', 'NEW') && !feeExists('PLNSGN010', 'INVOICED') ^ addFee('PLNSGN010', 'PLANNING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "PLN_SGN_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Temporary') && !feeExists('PLNSGN020', 'NEW') && !feeExists('PLNSGN020', 'INVOICED') ^ addFee('PLNSGN020', 'PLANNING', '2008.Q4', 1, 'N')"
	}, {
		"BIZDOMAIN" : "PLN_SGN_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Total square feet of signage') > 0 && !feeExists('PLNSGN040', 'NEW') && !feeExists('PLNSGN040', 'INVOICED') ^ addFee('PLNSGN040', 'PLANNING', 'FY 13-14', getAppSpecific('Total square feet of signage'), 'N')"
	}, {
		"BIZDOMAIN" : "PLN_SGN_PRMT_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "feeExists('PLNSGN050') && !feeExists('PLNSGNREF010', 'NEW') && !feeExists('PLNSGNREF010', 'INVOICED') ^ addFee( 'PLNSGNREF010','PLNSIGNS','2008.Q4', -feeAmount('PLNSGN050','INVOICED'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_SGN_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "6/23/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_SGN_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "6/23/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('PLNSGN050', 'NEW') && !feeExists('PLNSGN010', 'INVOICED') ^ addFee( 'PLNSGN050','PLNSIGNS','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan') && matches(getAppSpecific('Description'), 'Major') && !feeExists('PLNSTP010', 'NEW') && !feeExists('PLNSTP010', 'INVOICED') ^ addFee( 'PLNSTP010','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan') && matches(getAppSpecific('Description'), 'Minor') && !feeExists('PLNSTP020', 'NEW') && !feeExists('PLNSTP020', 'INVOICED') ^ addFee( 'PLNSTP020','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan Amendment') && matches(getAppSpecific('Description'), 'Major') && !feeExists('PLNSTP010', 'NEW') && !feeExists('PLNSTP010', 'INVOICED') ^ addFee( 'PLNSTP010','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNSTP010'); comment('varFA = ' + varFA);addFee( 'PLNSTP100','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNSTP010', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan Amendment') && matches(getAppSpecific('Description'), 'Minor') && !feeExists('PLNSTP020', 'NEW') && !feeExists('PLNSTP020', 'INVOICED') ^ addFee( 'PLNSTP020','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNSTP020'); comment('varFA = ' + varFA);addFee( 'PLNSTP100','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNSTP020', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan Extension') && matches(getAppSpecific('Description'), 'Major') && !feeExists('PLNSTP010', 'NEW') && !feeExists('PLNSTP010', 'INVOICED') ^ addFee( 'PLNSTP010','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNSTP010'); comment('varFA = ' + varFA);addFee( 'PLNSTP110','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNSTP010', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_STP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Site Plan Extension') && matches(getAppSpecific('Description'), 'Minor') && !feeExists('PLNSTP020', 'NEW') && !feeExists('PLNSTP020', 'INVOICED') ^ addFee( 'PLNSTP020','PLANNING','FY 13-14',getAppSpecific('# of Acres'), 'N');varFA=feeAmount('PLNSTP020'); comment('varFA = ' + varFA);addFee( 'PLNSTP110','PLANNING','2008.Q4',varFA*.5, 'N');removeFee('PLNSTP020', 'FY 13-14');"
	}, {
		"BIZDOMAIN" : "PLN_TUP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_TUP_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/15/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "!feeExists('PLNTUP010', 'NEW') && !feeExists('PLNTUP010', 'INVOICED') ^ addFee( 'PLNTUP010','PLANNING','2008.Q4', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_VAR_SUB_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; comment('*****PLANNING VARIANCE FEES*****');"
	}, {
		"BIZDOMAIN" : "PLN_VAR_SUB_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Variance') && matches(getAppSpecific('Use Type'), 'Residential') && !feeExists('PLNVAR010', 'NEW') && !feeExists('PLNVAR010', 'INVOICED') ^ addFee( 'PLNVAR010','PLANNING','FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_VAR_SUB_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Variance') && matches(getAppSpecific('Use Type'), 'Non-Residential') && !feeExists('PLNVAR020', 'NEW') && !feeExists('PLNVAR020', 'INVOICED') ^ addFee( 'PLNVAR020','PLANNING','FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_VAR_SUB_FEES",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Un-authorized construction/installation') && matches(getAppSpecific('Use Type'), 'Residential') && !feeExists('PLNVAR030', 'NEW') && !feeExists('PLNVAR030', 'INVOICED') ^ addFee( 'PLNVAR030','PLANNING','FY 13-14', 1, 'N');"
	}, {
		"BIZDOMAIN" : "PLN_VAR_SUB_FEES",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/16/2013",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Application Type'), 'Un-authorized construction/installation') && matches(getAppSpecific('Use Type'), 'Non-Residential') && !feeExists('PLNVAR040', 'NEW') && !feeExists('PLNVAR040', 'INVOICED') ^ addFee( 'PLNVAR040','PLANNING','FY 13-14', 1, 'N')"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('PLN_WorkflowTaskUpdateAfter branch worked!')"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch ('PLN_COU_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Rezone/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_REZ_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_GEN_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/House Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_HSE_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_PLT_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Administrative/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_ADM_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Relief/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_RLF_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Temporary Use Permit/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_TUP_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Variance/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_VAR_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Site Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_STP_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Rezone/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/House Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Administrative/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Relief/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Temporary Use Permit/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Variance/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Site Plan/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && balanceDue != 0 ^ comment('Application can not be accepted until the balance is paid');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Signs/*/*')  && wfStatus.equals('Calculate Permit Fees') ^ branch('PLN_SGN_PRMT_FEES')"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Clear Fees') ^ branch('REMVOVE_ESTIMATE_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 25,
		"BIZDOMAIN_VALUE2" : "A25",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ email('tstevens@avondale.org', 'AccelaEmail@avondale.org', 'Project is in Review - Planning Manager', 'The following project is in review:'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes());"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 26,
		"BIZDOMAIN_VALUE2" : "A26",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete')  ^ email('smcdermott@avondale.org', 'AccelaEmail@avondale.org', 'Project is in Review - Department Director', 'The following project is in review:'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes());"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 27,
		"BIZDOMAIN_VALUE2" : "A27",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') && {Send email to Economic Development Director}=='Yes' ^ email('ddavis@avondale.org', 'AccelaEmail@avondale.org', 'Project is in Review - Economic Development Director', 'The following project is in review.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes());"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 28,
		"BIZDOMAIN_VALUE2" : "A28",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Pre Application/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_PRE_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 29,
		"BIZDOMAIN_VALUE2" : "A29",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Pre Application/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ email('apreapmeetings@avondale.org', 'AccelaEmail@avondale.org', 'Project is in Pre-Ap', 'The following project is in pre-ap:' + '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'Application Type: ' + {Application Type} + '<br>' + 'Meeting Date: ' + {Meeting Date} + '<br>' + 'Meeting Time: ' + {Meeting Time} + '<br>' + 'Location: ' + {Location} + '<br>' + 'Planner: ' + {Planner})"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 30,
		"BIZDOMAIN_VALUE2" : "A30",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Signs/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch ('PLN_SGN_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 31,
		"BIZDOMAIN_VALUE2" : "A31",
		"REC_DATE" : "10/15/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Seasonal Sales Permit/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Calculate Submittal Fee') ^ branch('PLN_SEASON_SUB_FEES');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/8/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/8/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Overall Plan Check') && wfStatus.equals('Approved') ^ branch('OVERALL_PLAN_CHECK_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "12/8/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/*/*/*') && wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ branch('APPLICATION_BEFORE_UPDATE');"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "12/8/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Permit Issuance') && wfStatus.equals('Permit Issued') ^ branch('PERMIT_ISSUED_BEFORE_UPDATE')"
	}, {
		"BIZDOMAIN" : "PLN_WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "12/8/2011",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask.equals('Planning Admin Process') && wfStatus.equals('Complete') ^ editTaskDueDate('Overall Plan Check'),TaskDueDate('Overall Plan Check');"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Adjacent Property Owner 500' Map';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Adjacent Property Owner 500' Address List';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Adjacent Property Owner 500' Affidavit';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Title report/deed';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Project narrative';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Site plan, landscape plan, and floor plan';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Reduced copies of site plan, landscape plan, and floor plan (3 copies) 8.5 in x 11 in';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNCONUSE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/20/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'All plans on electronic file (PDF) labeled and dated';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Public participation completed forms';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Title report/deed';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Project narrative';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Existing General Plan Map with parcels highlighted 11 in x 17 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Current and proposed wording (for Text Amendment only)';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Legal description of property on separate 8.5 in x 11 in sheet';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNGENPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'All plans on electronic file (PDF) labeled and dated';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Complete review set';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Lot matrix';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Approved final plat reduced to 11in x 17 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Typical plot plans 8.5 in x 11 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Floor plans for each house 8.5 in x 11 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Elevations for each house (all four sides) 8.5 in x 11 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Front and rear streetscapes 8.5 in x 11 in';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Color combinations (with color palettes)';ASITableArray['Copies'] = '6'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Roof tile colors';ASITableArray['Copies'] = '4'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Roof tile types';ASITableArray['Copies'] = '4'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Garage doors';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Any options that affect the exterior';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNHSEPLN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'All plans on electronic file (PDF) labeled and dated';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Legal description of property on separate 8.5 in x 11 in sheet';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Title report/deed';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Copy of deed restrictions';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Utility letters';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Project narrative';ASITableArray['Copies'] = '6'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Map of Dedication';ASITableArray['Copies'] = '9'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Electronic copy on CD - MOD in AutoCAD';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Vacinity Map - MLD';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Preliminary plat';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Landscape plan';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Grading and drainage plan';ASITableArray['Copies'] = '4'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Drainage report 8.5 in x 11 in';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Water and sewer report 8.5 in x 11 in';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Alta survey';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'PP - Traffic impact study';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Reduced copies of preliminary plat  8.5 in x 11 in';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Reduced copies of landscape plan  8.5 in x 11 in';ASITableArray['Copies'] = '3'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 20,
		"BIZDOMAIN_VALUE2" : "A20",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Final plat';ASITableArray['Copies'] = '7'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 21,
		"BIZDOMAIN_VALUE2" : "A21",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Reduced copies of final plat';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 22,
		"BIZDOMAIN_VALUE2" : "A22",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Lot matrix';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 23,
		"BIZDOMAIN_VALUE2" : "A23",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Error of closure';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPLTFIN_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 24,
		"BIZDOMAIN_VALUE2" : "A24",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'All plans on electronic File (PDF) labeled and dated';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Pre App Questionaire';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Conceptual Drawings (folded 9'x 12 in')';ASITableArray['Copies'] = '8'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Title Report';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Project Narrative';ASITableArray['Copies'] = '8'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNPREAPP_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "8/10/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Site Context Photos (8 1/2 x 11 in')';ASITableArray['Copies'] = '8'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;ASITableArray = new Array;"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Completed application';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Legal description of property on separate 8.5 in x 11 in sheet';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Owner authorization form';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Title report/deed';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Public participation completed forms';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Project narrative';ASITableArray['Copies'] = '9'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Flood zone determination';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Plan narrative';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Development plan 24 in x 36 in';ASITableArray['Copies'] = '4'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Alta survey';ASITableArray['Copies'] = '2'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'Traffic impact study';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "PLNREZONE_ASI_DEF_SUBMITTED_DOCUMENTS",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "1/21/2009",
		"REC_FUL_NAM" : "ADMIN",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "true ^ ASITableArray['Document Name'] = 'All plans on electronic File (PDF) labeled and dated';ASITableArray['Copies'] = '1'; addToASITable('SUBMITTED DOCUMENTS', ASITableArray);"
	}, {
		"BIZDOMAIN" : "R_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; arrayFees= new Array; comment('***R _ REMOVE FEES**')"
	}, {
		"BIZDOMAIN" : "R_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ arrayFees = aa.fee.getFeeItems(capId).getOutput();"
	}, {
		"BIZDOMAIN" : "R_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) removeFee(arrayFees[x].getFeeCod(), '2008.Q4')"
	}, {
		"BIZDOMAIN" : "REMVOVE_ESTIMATE_FEES",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true; arrayFees= new Array;comment('**REMOVE FEES**')"
	}, {
		"BIZDOMAIN" : "REMVOVE_ESTIMATE_FEES",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ arrayFees = aa.fee.getFeeItems(capId).getOutput() ;"
	}, {
		"BIZDOMAIN" : "REMVOVE_ESTIMATE_FEES",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/1/2010",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ for (x in arrayFees) removeFee(arrayFees[x].getFeeCod(), '2008.Q4')"
	}, {
		"BIZDOMAIN" : "REVIEW_CONSOLIDATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug=true;showMessage=true;"
	}, {
		"BIZDOMAIN" : "REVIEW_CONSOLIDATION_BEFORE_UPDATE",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/25/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "getAppSpecific('Project in the Floodplain?') == 'Yes' && matches(getAppSpecific('Floodplain Construction Permit Issue Date'),null) ^ comment('Can not Approve if Floodplain is set to Yes and Floodplain Date is Blank');cancel=true;"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_10",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_10***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_10",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/Final Plat/*/*') || appMatch('Planning/Rezone/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for CC. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_11",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_11***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_11",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/General Plan/*/*') || appMatch('Planning/Final Plat/*/*') || appMatch('Planning/Rezone/*/*') || appMatch('Planning/Site Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered CC Hearing. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_12",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_12***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_12",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/General Plan/*/*') || appMatch('Planning/Final Plat/*/*') || appMatch('Planning/Rezone/*/*') || appMatch('Planning/Site Plan/*/*') || appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Documentation. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_13",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_13***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_13",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered PC Hearing 1. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_14",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_14***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_14",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for PC 2. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_15",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_15***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_15",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered PC Hearing 2. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_16",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_16***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_16",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for CC. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_17",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_17***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_17",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Documentation. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_18",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_18***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_18",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Mylar Sign-Off. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_18",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/*/*/*') && !appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_19",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_19***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_19",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 2. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_2***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Accessory Use/*') || appMatch('Building/Building Safety/Model Home Complex/*') || (appMatch('Building/Building Safety/Standard Plans/*') && matches(getAppSpecific('Plan Type'), 'SFD')) ^ email('aBuildingPlanningReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') || appMatch('Building/Building Safety/Pool-Spa/*') || appMatch('Building/Building Safety/Review/*') ^ email('aBuildingCounterReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') || appMatch('Building/Building Safety/Residential/*') ^ email('aDeptReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') && matches(getAppSpecific('Plan Type'), 'Pool/Spa') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aBuildingFireReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/*/*/*') && !appMatch('Planning/Administrative/*/*') && !appMatch('Planning/Relief/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Plan Check. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Relief/*/*') || appMatch('Planning/Administrative/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Staff Review. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Plot Plan Review. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_2",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Map Revision/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Engineering Staff Review. Please complete next workflow tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_20",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_20***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_20",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Mylars to Client. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_21",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_21***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_21",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Mylar Distribution. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_22",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_22***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_22",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_23",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_23***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_23",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Code/*') || appMatch('Building/Building Safety/Pool-Spa/*') || appMatch('Planning/Signs/*/*') ^ email('aBuildingInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Inspections. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_23",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aFireInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Inspections. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_23",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') ^ email('aEngInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Final Inspection. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_23",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Accessory Use/*') || appMatch('Building/Building Safety/Commercial Buildings/*') || appMatch('Building/Building Safety/Residential/*') || appMatch('Building/Building Safety/Standard Plan SFD Permit/*') ^ email('aBuildingInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Fire Inspections. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_24",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_24***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_24",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Model Home Complex/*') || appMatch('Building/Building Safety/Review/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_24",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Map Revision/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_24",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Technical Assistance Review/*') ^ email('aBuildingFireReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_24",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Plan Release. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_25",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_25***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_25",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Pool-Spa/*') || appMatch('Building/Building Safety/Code/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_25",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Signs/*/*') ^ email('aBuildingPlanningReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_25",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') || appMatch('Building/Building Safety/Accessory Use/*') || appMatch('Building/Building Safety/Standard Plan SFD Permit/*') || appMatch('Building/Building Safety/Residential/*') ^ email('aBuildingCofOCofC@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered C of O/C of C . Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_26",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_26***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_26",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Submit As-Builts. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_27",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_27***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_27",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Commercial Buildings/*') || appMatch('Building/Building Safety/Accessory Use/*') || appMatch('Building/Building Safety/Standard Plan SFD Permit/*') || appMatch('Building/Building Safety/Residential/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure . Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_28",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_28***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_28",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Create Model . Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_29",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_29***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_29",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plans/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure . Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_3",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_3***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_3",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/*/*') || appMatch('Building/Civil Engineering/*/*') || appMatch('Building/Fire Prevention/Technical Assistance Review/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_3",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/General Plan/*/*') || appMatch('Planning/Variance/*/*') || appMatch('Planning/House Plan/*/*') || appMatch('Planning/Rezone/*/*') || appMatch('Planning/Signs/*/*') || appMatch('Planning/Site Plan/*/*') || appMatch('Planning/Temporary Use Permit/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_3",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') && !appMatch('Building/Fire Prevention/Technical Assistance Review/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 01. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_3",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Final Plat/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 1. Please complete next Workflow Tasks'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_30",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_30***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_30",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 2. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_31",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_31***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_31",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Submit As-Builts. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_31",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Utility Permit/*') ^ email('aEngInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Acceptance. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_32",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_32***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_32",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Engineering Review As-Builts. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_32",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aFireAsBuiltReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Review As-Builts . Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_33",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_33***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_33",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 3. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_34",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_34***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_34",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aEngInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Acceptance. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_35",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_35***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_35",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') ^ email('aEngInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Warranty Inspections. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_36",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_36***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_36",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') ^ email('aEngInspections@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_37",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_37***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_37",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal 02. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_38",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_38***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_38",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ email('aBuildingFireReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_39",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_39***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_39",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Pre Application/*/*') ^ email('aPlanners@avondale.org' 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Closure. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_4",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_4***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_4",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Standard Plan SFD Permit/*') ^ email('aCounter@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_40",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_40***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_40",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Variance/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered BofA Hearing. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_41",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_41***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_41",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Variance/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Documentation. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_5",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_5***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_5",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Administrative/*/*') || appMatch('Planning/Relief/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Transmittal. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_6***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/Model Home Complex/*') || appMatch('Building/Building Safety/Review/*') || appMatch('Building/Building Safety/Standard Plans/*') ^ email('aBuildingReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Approval. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/Technical Assistance Review/*') ^ email('aBuildingFireReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Approval. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Improvement Plan/*') ^ email('aEngFireReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Overall Mylar Review. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/House Plan/*/*') || appMatch('Planning/Temporary Use Permit/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Documentation. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/Final Plat/*/*') || appMatch('Planning/Rezone/*/*') || appMatch('Planning/Site Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for PC. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes()+ '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/General Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for PC 1. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Pre Application/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Hold Meeting. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_6",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Variance/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Prepare Docs for BofA. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_7",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_7***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_7",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/Map Revision/*') ^ email('aEngProjectReview@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Approval. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_8",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_8***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_8",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Administrative/*/*') || appMatch('Planning/Relief/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered Documentation. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_9",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment('***SEND_EMAIL_9***');"
	}, {
		"BIZDOMAIN" : "SND_EMAIL_9",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "7/24/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/Conditional Use/*/*') || appMatch('Planning/Final Plat/*/*') || appMatch('Planning/Rezone/*/*') || appMatch('Planning/Site Plan/*/*') ^ email('aPlanners@avondale.org', 'AccelaEmail@avondale.org','Workflow Tasks', 'The following project has entered PC Hearing. Please complete next Workflow Tasks.'+ '<br>' + '<br>' + 'Project ID: ' + capIDString + '<br>' + '<br>' + 'Project Name: ' + getShortNotes() + '<br>' + '<br>' + 'https://aa.avondale.org');"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;comment('**Task Due Date Assign***'); varD = {filedate};"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ varX = parseInt(getAppSpecific('Current Plan Review #')) + 1;editAppSpecific('Current Plan Review #', varX);"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Current Plan Review #'),1) ^ editTaskDueDate('Building Staff Review',getDateDue(12));editTaskDueDate('DSC Staff Review',getDateDue(12));editTaskDueDate('Economic Development Director',getDateDue(12));editTaskDueDate('Engineering Staff Review',getDateDue(12));editTaskDueDate('EPR Staff Review',getDateDue(12));editTaskDueDate('Field Operations Review',getDateDue(12));editTaskDueDate('Fire Staff Review',getDateDue(12));editTaskDueDate('GIS Staff Review',getDateDue(12));editTaskDueDate('Planning Manager',getDateDue(12));editTaskDueDate('Planning Staff Review',getDateDue(12));editTaskDueDate('Police Staff Review',getDateDue(12));editTaskDueDate('Traffic Staff Review',getDateDue(12));editTaskDueDate('Water Resources Review',getDateDue(12));editTaskDueDate('Overall Plan Check',getDateDue(12));editTaskDueDate('Land Services Review',getDateDue(12));editTaskDueDate('Landscape Architect Review',getDateDue(12));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "varX > 1 ^ editTaskDueDate('Building Staff Review',getDateDue(8));editTaskDueDate('DSC Staff Review',getDateDue(8));editTaskDueDate('Economic Development Director',getDateDue(8));editTaskDueDate('Engineering Staff Review',getDateDue(8));editTaskDueDate('EPR Staff Review',getDateDue(8));editTaskDueDate('Field Operations Review',getDateDue(8));editTaskDueDate('Fire Staff Review',getDateDue(8));editTaskDueDate('GIS Staff Review',getDateDue(8));editTaskDueDate('Planning Manager',getDateDue(8));editTaskDueDate('Planning Staff Review',getDateDue(8));editTaskDueDate('Police Staff Review',getDateDue(8));editTaskDueDate('Traffic Staff Review',getDateDue(8));editTaskDueDate('Water Resources Review',getDateDue(8));editTaskDueDate('Overall Plan Check',getDateDue(8));editTaskDueDate('Land Services Review',getDateDue(8));editTaskDueDate('Landscape Architect Review',getDateDue(8));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Current Plan Review #'),1) ^ editTaskDueDate('Buidling Staff Review',getDateDue(12));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "9/4/2014",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "varX > 1 ^ editTaskDueDate('Buidling Staff Review',getDateDue(8));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN2",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/12/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = true; showMessage = true;comment('**Task Due Date Assign2***')"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN2",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/12/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ editTaskDueDate('Building Staff Review',getDateDue(8));editTaskDueDate('DSC Staff Review',getDateDue(8));editTaskDueDate('Economic Development Director',getDateDue(8));editTaskDueDate('Engineering Staff Review',getDateDue(8));editTaskDueDate('EPR Staff Review',getDateDue(8));editTaskDueDate('Field Operations Review',getDateDue(8));editTaskDueDate('Fire Staff Review',getDateDue(8));editTaskDueDate('GIS Staff Review',getDateDue(8));editTaskDueDate('Planning Manager',getDateDue(8));editTaskDueDate('Planning Staff Review',getDateDue(8));editTaskDueDate('Police Staff Review',getDateDue(8));editTaskDueDate('Traffic Staff Review',getDateDue(8));editTaskDueDate('Water Resources Review',getDateDue(8));editTaskDueDate('Overall Plan Check',getDateDue(8));editTaskDueDate('Land Services Review',getDateDue(8));editTaskDueDate('Landscape Architect Review',getDateDue(8));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN3",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "9/17/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = true; showMessage = true;comment('**Task Due Date Assign3***')"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN3",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "9/17/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ varX = parseInt(getAppSpecific('Completeness Review #')) + 1;editAppSpecific('Completeness Review #', varX);"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN3",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "9/17/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "matches(getAppSpecific('Completeness Review #'),1) ^ editTaskDueDate('Completeness Review',getDateDue(8));"
	}, {
		"BIZDOMAIN" : "TASK_DUE_DATE_ASSIGN3",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "9/17/2013",
		"REC_FUL_NAM" : "ROCKYM",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "varX > 1 ^ editTaskDueDate('Completeness Review',getDateDue(6));"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ showDebug = false; showMessage = true;"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ comment('***WorkflowTaskUpdateAfter branch worked!***')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/*/*') ^ branch('BLD_WorkflowTaskUpdateAfter')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') ^ branch('ENG_WorkflowTaskUpdateAfter')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ branch('FP_WorkflowTaskUpdateAfter')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/*/*/*') ^ branch('PLN_WorkflowTaskUpdateAfter')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete') ^ branch('TASK_DUE_DATE_ASSIGN')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "isTaskActive('Closure') ^ branchTask('Closure','Closed');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 09,
		"BIZDOMAIN_VALUE2" : "A09",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true ^ branch('BLD_EMAIL_AFTER');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 10,
		"BIZDOMAIN_VALUE2" : "A10",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfStatus.equals('Cancelled') ^ taskCloseAllExcept('Closure', 'Cancelled');activateTask('Closure');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 11,
		"BIZDOMAIN_VALUE2" : "A11",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Revision Submitted') ^ branch('TASK_DUE_DATE_ASSIGN2')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 12,
		"BIZDOMAIN_VALUE2" : "A12",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Completeness Review Required') ^ branch('TASK_DUE_DATE_ASSIGN3')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 13,
		"BIZDOMAIN_VALUE2" : "A13",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Plan Distribution') && wfStatus.equals('Plan Distributed for Review') ^ branch('TASK_DUE_DATE_ASSIGN')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 14,
		"BIZDOMAIN_VALUE2" : "A14",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Application Acceptance') && wfStatus.equals('Complete Substantive') ^ branch('TASK_DUE_DATE_ASSIGN2')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 15,
		"BIZDOMAIN_VALUE2" : "A15",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask == 'Plan Distribution' && matches(wfStatus, 'Approved', 'Not Approved') ^ emailEveryone('Plans Consolidation', 'The Plan Distribution task has been set to a status of ' + wfStatus + ' on permit ' + capIDString + '.');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 16,
		"BIZDOMAIN_VALUE2" : "A16",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask == 'Permit Issuance' && matches(wfStatus, 'Permit Issued', 'Issued') ^ emailEveryone('Permit Issued', 'Permit ' + capIDString + ' has been issued.');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 17,
		"BIZDOMAIN_VALUE2" : "A17",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask == 'C of O/C of C' && wfStatus == 'Issued' ^ emailEveryone('CO Issued', 'CO Issued for permit ' + capIDString + '.');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 18,
		"BIZDOMAIN_VALUE2" : "A18",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask == 'Review Consolidation' ^  emailEveryone('Review Consolidation', 'The Review Consolidation task has been set to a status of ' + wfStatus + ' on permit ' + capIDString + '.');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateAfter",
		"BIZDOMAIN_VALUE" : 19,
		"BIZDOMAIN_VALUE2" : "A19",
		"REC_DATE" : "3/25/2015",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "wfTask == 'Inspections' && wfStatus == 'Revision Required' ^ emailEveryone('Revision Required', 'Revisions are required  on permit ' + capIDString + '.');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 01,
		"BIZDOMAIN_VALUE2" : "A01",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "true^showDebug = false;showMessage=true;comment ('WorkflowTaskUpdateBefore...It Worked')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 02,
		"BIZDOMAIN_VALUE2" : "A02",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Building Safety/*/*') ^ branch('BLD_WorkflowTaskUpdateBefore')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 03,
		"BIZDOMAIN_VALUE2" : "A03",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Civil Engineering/*/*') ^ branch('ENG_WorkflowTaskUpdateBefore')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 04,
		"BIZDOMAIN_VALUE2" : "A04",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Building/Fire Prevention/*/*') ^ branch('FP_WorkflowTaskUpdateBefore')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 05,
		"BIZDOMAIN_VALUE2" : "A05",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "appMatch('Planning/*/*/*') ^ branch('PLN_WorkflowTaskUpdateBefore')"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 06,
		"BIZDOMAIN_VALUE2" : "A06",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Closure') && wfStatus.equals('Closed') && {Updated.Retention/Disposition} == 'Temporary' && {Updated.Disposal Date} == '' ^ comment('Please provide a disposal date');cancel=true;"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 07,
		"BIZDOMAIN_VALUE2" : "A07",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "I",
		"VALUE_DESC" : "isTaskActive('Closure') ^ branchTask('Closure','Closed');"
	}, {
		"BIZDOMAIN" : "WorkflowTaskUpdateBefore",
		"BIZDOMAIN_VALUE" : 08,
		"BIZDOMAIN_VALUE2" : "A08",
		"REC_DATE" : "12/9/2014",
		"REC_FUL_NAM" : "LINDAS",
		"REC_STATUS" : "A",
		"VALUE_DESC" : "wfTask.equals('Review Consolidation') && wfStatus.equals('Approved') ^ branch('REVIEW_CONSOLIDATION_BEFORE_UPDATE')"
	}
]
var args = new Array();
var bm = aa.proxyInvoker.newInstance("com.accela.aa.aamain.systemConfig.RBizDomainModel", args).getOutput();
var r = aa.proxyInvoker.newInstance("com.accela.aa.aamain.systemConfig.BizDomainBusiness").getOutput();
for (var i in x) {
	row = x[i];
	bm.setServiceProviderCode(aa.getServiceProviderCode());
	bm.setBizDomain(row.BIZDOMAIN);
	bm.setDescription("");
	bm.setType("EMSE");
	bm.setAuditDate(new Date());
	bm.setAuditID("ADMIN");
	bm.setAuditStatus("A");
	try {
		r.createRBizDomain(bm);
	} catch (err) {
		aa.print("error creating biz: " + row.BIZDOMAIN)
	}
	z = aa.bizDomain.createBizDomain(row.BIZDOMAIN, row.BIZDOMAIN_VALUE2, row.REC_STATUS, row.VALUE_DESC);
	aa.print(z.getSuccess());
}
