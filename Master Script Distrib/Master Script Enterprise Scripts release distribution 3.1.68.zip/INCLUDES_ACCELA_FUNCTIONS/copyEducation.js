 function copyEducation(srcCapId, targetCapId)
{
    if(srcCapId != null && targetCapId != null)
    {
        aa.education.copyEducationList(srcCapId, targetCapId);
    }
}
