showDebug = matches(currentUserID,"ADMIN);
